export type UserRole = 'consumer' | 'engineer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatarUrl?: string;
  consumerId?: string;
  state?: string;
  district?: string;
}

export type ComplaintCategory =
  | 'Power Outage'
  | 'Low Voltage'
  | 'High Voltage'
  | 'Transformer Damage'
  | 'Burnt Meter'
  | 'Broken Pole'
  | 'Hanging Wire'
  | 'Street Light Failure'
  | 'Electric Shock Hazard'
  | 'Billing Issue'
  | 'Meter Not Working'
  | 'Illegal Connection';

export type ComplaintStatus = 'Submitted' | 'Acknowledged' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed';
export type SeverityLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type PriorityLevel = 'Low' | 'Medium' | 'High' | 'Immediate';

export interface LocationData {
  latitude?: number;
  longitude?: number;
  address?: string;
  state?: string;
  district?: string;
}

export interface Complaint {
  id: string;
  ticketNumber: string;
  consumerId: string;
  consumerName: string;
  consumerPhone: string;
  category: ComplaintCategory;
  description: string;
  location: LocationData;
  imageUrl?: string;
  voiceUrl?: string;
  status: ComplaintStatus;
  severity: SeverityLevel;
  priority: PriorityLevel;
  department: string;
  engineerId?: string;
  engineerName?: string;
  aiAnalysis?: AIAnalysisResult;
  createdAt: string;
  updatedAt: string;
  resolutionTimeMinutes?: number;
}

export interface AIAnalysisResult {
  category: ComplaintCategory;
  priority: PriorityLevel;
  severity: SeverityLevel;
  department: string;
  summary: string;
  safety: string[];
  confidence: number;
  duplicateDetected: boolean;
  duplicateTicketNumber?: string;
  engineerSummary: string;
}

export interface StatusLog {
  id: string;
  complaintId: string;
  status: ComplaintStatus;
  updatedBy: string;
  updatedByName: string;
  comments: string;
  createdAt: string;
}

export interface Engineer {
  id: string;
  name: string;
  phone: string;
  department: string;
  status: 'Active' | 'On Field' | 'On Leave';
  activeComplaintsCount: number;
  resolvedComplaintsCount: number;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'status_update' | 'assignment' | 'critical_hazard' | 'billing';
  isRead: boolean;
  createdAt: string;
}

export interface AnalyticsSummary {
  total: number;
  pending: number;
  resolved: number;
  critical: number;
  todayCount: number;
  categoryDistribution: Record<string, number>;
  severityDistribution: Record<string, number>;
  statusDistribution: Record<string, number>;
  dailyTrends: { date: string; submitted: number; resolved: number }[];
  resolutionTimeTrend: { date: string; avgTimeMinutes: number }[];
}
