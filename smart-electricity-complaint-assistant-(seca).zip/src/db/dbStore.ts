import { Complaint, User, StatusLog, Engineer, AppNotification, AnalyticsSummary, ComplaintCategory, PriorityLevel, SeverityLevel, ComplaintStatus } from '../types';

// Standard pre-seeded users
export const PRE_SEEDED_USERS: User[] = [
  {
    id: 'usr-consumer',
    name: 'Rajesh Kumar',
    email: 'consumer@seca.in',
    phone: '+91 98765 43210',
    role: 'consumer',
    consumerId: 'CON-DL-4028492',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    state: 'Delhi',
    district: 'West Delhi',
  },
  {
    id: 'usr-engineer',
    name: 'Amit Sharma',
    email: 'engineer@seca.in',
    phone: '+91 87654 32109',
    role: 'engineer',
    avatarUrl: 'https://images.unsplash.com/photo-1621574539437-4b7cb63120b8?w=150',
    state: 'Delhi',
    district: 'West Delhi',
  },
  {
    id: 'usr-admin',
    name: 'Er. Sanjay Patil',
    email: 'admin@seca.in',
    phone: '+91 76543 21098',
    role: 'admin',
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
    state: 'Delhi',
    district: 'Corporate Headquarters',
  }
];

// Seeded Engineers
export const PRE_SEEDED_ENGINEERS: Engineer[] = [
  {
    id: 'eng-1',
    name: 'Amit Sharma',
    phone: '+91 87654 32109',
    department: 'Overhead Lines & Poles',
    status: 'On Field',
    activeComplaintsCount: 2,
    resolvedComplaintsCount: 14,
  },
  {
    id: 'eng-2',
    name: 'Priya Nair',
    phone: '+91 94460 11223',
    department: 'Transformers & Substations',
    status: 'Active',
    activeComplaintsCount: 1,
    resolvedComplaintsCount: 22,
  },
  {
    id: 'eng-3',
    name: 'Vikram Singh',
    phone: '+91 98100 88776',
    department: 'Metering & Billing',
    status: 'Active',
    activeComplaintsCount: 1,
    resolvedComplaintsCount: 31,
  },
  {
    id: 'eng-4',
    name: 'Rajesh Patel',
    phone: '+91 93771 55443',
    department: 'Street Lighting',
    status: 'On Field',
    activeComplaintsCount: 0,
    resolvedComplaintsCount: 18,
  }
];

// Dynamic Seeded Complaints
const baseDate = new Date();
const formatDateOffset = (daysAgo: number, hoursOffset: number = 0) => {
  const d = new Date(baseDate);
  d.setDate(d.getDate() - daysAgo);
  d.setHours(d.getHours() - hoursOffset);
  return d.toISOString();
};

export const PRE_SEEDED_COMPLAINTS: Complaint[] = [
  {
    id: 'comp-1',
    ticketNumber: 'SECA-2026-0001',
    consumerId: 'CON-DL-4028492',
    consumerName: 'Rajesh Kumar',
    consumerPhone: '+91 98765 43210',
    category: 'Hanging Wire',
    description: 'A heavy branch fell on the main overhead electrical wire during yesterday evening\'s storm. The wire is now hanging extremely low, touching the metal boundary fence of our residential society park. Children play here. It is highly dangerous as it might sparking anytime.',
    location: {
      latitude: 28.6139,
      longitude: 77.2090,
      address: 'Gate No. 3, Block C, Janakpuri, New Delhi, Delhi 110058',
      state: 'Delhi',
      district: 'West Delhi'
    },
    imageUrl: 'https://images.unsplash.com/photo-1623157474431-7290ec59bb6a?w=600', // hanging wire style
    status: 'Assigned',
    severity: 'Critical',
    priority: 'Immediate',
    department: 'Overhead Lines & Poles',
    engineerId: 'eng-1',
    engineerName: 'Amit Sharma',
    createdAt: formatDateOffset(1, 4),
    updatedAt: formatDateOffset(1, 2),
    aiAnalysis: {
      category: 'Hanging Wire',
      priority: 'Immediate',
      severity: 'Critical',
      department: 'Overhead Lines & Poles',
      summary: 'High-risk situation of hanging overhead electrical wires touching public metal fencing due to tree branch impact.',
      safety: [
        'DO NOT touch the wire, the fence, or any wet surface nearby.',
        'Keep children, pets, and bystanders at least 15 meters away from the area.',
        'Warn others about the live electrical hazard in the vicinity.',
        'Wait for the emergency utility response team to turn off power.'
      ],
      confidence: 96,
      duplicateDetected: false,
      engineerSummary: 'Urgent task: De-energize overhead feeder line at Janakpuri Block C immediately. Clear tree branches, repair damaged tension wire, tension conductors, and verify safety before power restoration.'
    }
  },
  {
    id: 'comp-2',
    ticketNumber: 'SECA-2026-0002',
    consumerId: 'CON-KA-1192842',
    consumerName: 'Lakshmi Prasad',
    consumerPhone: '+91 94800 22110',
    category: 'Transformer Damage',
    description: 'Our colony transformer (100 KVA) is making a loud buzzing, crackling noise and there is visual sparking accompanied by heavy black smoke and a strong burning oil smell. Power is completely cut off for 50+ households around indiranagar.',
    location: {
      latitude: 12.9716,
      longitude: 77.5946,
      address: 'Near 12th Cross Main Road, Indiranagar, Bengaluru, Karnataka 560038',
      state: 'Karnataka',
      district: 'Bengaluru Urban'
    },
    imageUrl: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600', // high power tower / transformer style
    status: 'In Progress',
    severity: 'Critical',
    priority: 'Immediate',
    department: 'Transformers & Substations',
    engineerId: 'eng-2',
    engineerName: 'Priya Nair',
    createdAt: formatDateOffset(0, 5),
    updatedAt: formatDateOffset(0, 3),
    aiAnalysis: {
      category: 'Transformer Damage',
      priority: 'Immediate',
      severity: 'Critical',
      department: 'Transformers & Substations',
      summary: 'Transformer overheating, sparking, and smoking, causing structural breakdown and active power outage for 50+ consumers.',
      safety: [
        'Maintain a safe distance of at least 25 meters from the smoking transformer.',
        'In case of fire, do not throw water on it under any circumstances.',
        'Instruct residents to disconnect sensitive electrical appliances in their homes.',
        'Keep fire extinguishers nearby but do not attempt active firefighting unless authorized.'
      ],
      confidence: 98,
      duplicateDetected: false,
      engineerSummary: 'Immediate physical inspection required: Isolate the faulty transformer, pump oil sample if possible, check for winding short-circuits. Likely requires oil refilling or replacement of transformer unit.'
    }
  },
  {
    id: 'comp-3',
    ticketNumber: 'SECA-2026-0003',
    consumerId: 'CON-UP-8849201',
    consumerName: 'Arvind Singh',
    consumerPhone: '+91 98112 33445',
    category: 'Street Light Failure',
    description: 'Street lights along Sector 15 main commercial street are not working for the last 5 days. It is completely pitch dark after 7 PM, leading to security issues for women and elderly walking from the metro station.',
    location: {
      latitude: 28.5831,
      longitude: 77.3149,
      address: 'Main Market Road, Sector 15, Noida, Uttar Pradesh 201301',
      state: 'Uttar Pradesh',
      district: 'Gautam Buddha Nagar'
    },
    status: 'Resolved',
    severity: 'Low',
    priority: 'Low',
    department: 'Street Lighting',
    engineerId: 'eng-4',
    engineerName: 'Rajesh Patel',
    createdAt: formatDateOffset(3, 8),
    updatedAt: formatDateOffset(1, 1),
    resolutionTimeMinutes: 2940, // about 2 days
    aiAnalysis: {
      category: 'Street Light Failure',
      priority: 'Low',
      severity: 'Low',
      department: 'Street Lighting',
      summary: 'Non-functional street light assembly over an entire stretch, creating public safety and visibility concerns.',
      safety: [
        'Avoid walking alone in the dark stretch at night.',
        'Use mobile phone flashlights or pocket torches for visibility.',
        'Be alert about active vehicle traffic due to low illumination.'
      ],
      confidence: 94,
      duplicateDetected: false,
      engineerSummary: 'Replace damaged automatic timer switch/photocell sensor in the central lighting control box. Inspect overhead cables for phase breaks.'
    }
  },
  {
    id: 'comp-4',
    ticketNumber: 'SECA-2026-0004',
    consumerId: 'CON-MH-3381920',
    consumerName: 'Deepa Deshmukh',
    consumerPhone: '+91 91223 44556',
    category: 'Billing Issue',
    description: 'Received an absurdly high electricity bill of ₹48,520 for June. Usually, our bill is around ₹3,000 to ₹4,500 maximum. The meter reading shown in the bill does not match the actual reading on our meter unit.',
    location: {
      latitude: 19.1245,
      longitude: 72.8988,
      address: 'Hiranandani Gardens, Powai, Mumbai, Maharashtra 400076',
      state: 'Maharashtra',
      district: 'Mumbai Suburban'
    },
    status: 'Submitted',
    severity: 'Medium',
    priority: 'Medium',
    department: 'Metering & Billing',
    createdAt: formatDateOffset(0, 1),
    updatedAt: formatDateOffset(0, 1),
    aiAnalysis: {
      category: 'Billing Issue',
      priority: 'Medium',
      severity: 'Medium',
      department: 'Metering & Billing',
      summary: 'Extremely high bill spike discrepancy, suspected incorrect meter reading input or faulty billing generation.',
      safety: [
        'Check if there are any physical tampering signs on your meter.',
        'Do not pay the inflated bill immediately; register a verification first.',
        'Take a clear photograph of your current digital meter reading.'
      ],
      confidence: 95,
      duplicateDetected: false,
      engineerSummary: 'Compare billed units with a physical photo verification. Revise consumer ledger entry if a punching typo is discovered in meter-reader records.'
    }
  },
  {
    id: 'comp-5',
    ticketNumber: 'SECA-2026-0005',
    consumerId: 'CON-TN-9920194',
    consumerName: 'Karthik Subramanian',
    consumerPhone: '+91 94440 88220',
    category: 'Burnt Meter',
    description: 'During heavy rain today afternoon, we heard a small pop sound from our home main board. The digital electricity meter was smoking and now it is completely black, burnt, and dead. Our home is completely without power, although neighbors have electricity.',
    location: {
      latitude: 13.0067,
      longitude: 80.2571,
      address: 'Lattice Bridge Road, Adyar, Chennai, Tamil Nadu 600020',
      state: 'Tamil Nadu',
      district: 'Chennai'
    },
    status: 'Assigned',
    severity: 'High',
    priority: 'High',
    department: 'Metering & Billing',
    engineerId: 'eng-3',
    engineerName: 'Vikram Singh',
    createdAt: formatDateOffset(0, 6),
    updatedAt: formatDateOffset(0, 2),
    aiAnalysis: {
      category: 'Burnt Meter',
      priority: 'High',
      severity: 'High',
      department: 'Metering & Billing',
      summary: 'Burnt consumer meter board due to overvoltage spike, resulting in localized power failure for a single consumer.',
      safety: [
        'Do not try to switch on or touch the main breaker or the burnt meter box.',
        'Keep a dry chemical fire extinguisher handy in case of smoke flare-ups.',
        'Call an independent electrician to check internal house wiring before meter replacement.'
      ],
      confidence: 97,
      duplicateDetected: false,
      engineerSummary: 'Install new single-phase static digital meter. Check main incoming service line cable for short circuit. Re-torque contact points.'
    }
  },
  {
    id: 'comp-6',
    ticketNumber: 'SECA-2026-0006',
    consumerId: 'CON-DL-4028492',
    consumerName: 'Rajesh Kumar',
    consumerPhone: '+91 98765 43210',
    category: 'Low Voltage',
    description: 'Extremely low voltage in Block D, Janakpuri for the past 6 hours. Fans are rotating very slowly, lights are flickering, and the AC or refrigerator is failing to start. It is impossible to sit in this hot weather.',
    location: {
      latitude: 28.6215,
      longitude: 77.1124,
      address: 'Block D, Near District Center, Janakpuri, New Delhi 110058',
      state: 'Delhi',
      district: 'West Delhi'
    },
    status: 'Acknowledged',
    severity: 'Medium',
    priority: 'Medium',
    department: 'Transformers & Substations',
    createdAt: formatDateOffset(0, 8),
    updatedAt: formatDateOffset(0, 4),
    aiAnalysis: {
      category: 'Low Voltage',
      priority: 'Medium',
      severity: 'Medium',
      department: 'Transformers & Substations',
      summary: 'Sustained voltage sag affecting household appliances, likely caused by local feeder overloading or phase imbalance.',
      safety: [
        'Turn off high-load appliances like ACs, water heaters, and refrigerators to prevent motor burnout.',
        'Keep light bulbs off if flickering heavily.',
        'Avoid touch connection points on voltage stabilizers.'
      ],
      confidence: 91,
      duplicateDetected: false,
      engineerSummary: 'Measure voltage at consumer terminal and incoming distribution box. Check tap settings of local 400KVA transformer. Balances phases if load is uneven.'
    }
  },
  {
    id: 'comp-7',
    ticketNumber: 'SECA-2026-0007',
    consumerId: 'CON-DL-8839201',
    consumerName: 'Sunita Sharma',
    consumerPhone: '+91 95551 12233',
    category: 'Broken Pole',
    description: 'A heavy commercial delivery vehicle reversed blindly last night and hit the main street lighting pole. The pole is cracked at the bottom and is now tilting at 45 degrees, hanging dangerously over the pedestrian sidewalk near Sector 10.',
    location: {
      latitude: 28.5950,
      longitude: 77.0700,
      address: 'Near Metro Station Gate 1, Sector 10, Dwarka, New Delhi 110075',
      state: 'Delhi',
      district: 'West Delhi'
    },
    status: 'Assigned',
    severity: 'High',
    priority: 'High',
    department: 'Overhead Lines & Poles',
    engineerId: 'eng-1',
    engineerName: 'Amit Sharma',
    createdAt: formatDateOffset(1, 12),
    updatedAt: formatDateOffset(1, 2),
    aiAnalysis: {
      category: 'Broken Pole',
      priority: 'High',
      severity: 'High',
      department: 'Overhead Lines & Poles',
      summary: 'Vehicular collision causing structural cracking and high risk of overhead conductor snap or structural pole collapse.',
      safety: [
        'Do not walk under or park any vehicle near the tilting pole.',
        'Warn pedestrians to use the opposite sidewalk.',
        'Keep safe distance in case the pole fully snaps.'
      ],
      confidence: 95,
      duplicateDetected: false,
      engineerSummary: 'Secure site. Bring crane and replacement concrete pole. Isolate overhead conductor lines, safely dismantle old pole, install and anchor new reinforced pole.'
    }
  },
  {
    id: 'comp-8',
    ticketNumber: 'SECA-2026-0008',
    consumerId: 'CON-DL-5520194',
    consumerName: 'Gaurav Sen',
    consumerPhone: '+91 88440 99331',
    category: 'Electric Shock Hazard',
    description: 'Due to ongoing monsoons and water-logging on the main street, we are receiving minor electrical shocks when coming into contact with the street light pole near Block C market. It is extremely scary as people wade through this water.',
    location: {
      latitude: 28.6150,
      longitude: 77.1600,
      address: 'Main Market Crossing, Block C, Rajouri Garden, New Delhi 110027',
      state: 'Delhi',
      district: 'West Delhi'
    },
    status: 'In Progress',
    severity: 'Critical',
    priority: 'Immediate',
    department: 'Overhead Lines & Poles',
    engineerId: 'eng-4',
    engineerName: 'Rajesh Patel',
    createdAt: formatDateOffset(0, 3),
    updatedAt: formatDateOffset(0, 1),
    aiAnalysis: {
      category: 'Electric Shock Hazard',
      priority: 'Immediate',
      severity: 'Critical',
      department: 'Overhead Lines & Poles',
      summary: 'Water-logged public street pole showing active current leakage, posing high fatal risk to waders and animals.',
      safety: [
        'STAY AWAY from the water-logged street around the pole.',
        'Never touch any metallic street structures or poles during rain.',
        'Inform neighborhood children to avoid the market crossing.'
      ],
      confidence: 99,
      duplicateDetected: false,
      engineerSummary: 'Urgent leakage checks using tester. Check insulation values, inspect internal street lighting wires for insulation peel, install fresh grounding wire connection.'
    }
  },
  {
    id: 'comp-9',
    ticketNumber: 'SECA-2026-0009',
    consumerId: 'CON-DL-1102931',
    consumerName: 'Manpreet Singh',
    consumerPhone: '+91 99112 88442',
    category: 'Power Outage',
    description: 'Complete power cut for the last 4 hours in Sector 2 market area. All shops are running on diesel generators which are causing extreme noise and smoke pollution. No update has been received from the sub-station.',
    location: {
      latitude: 28.6250,
      longitude: 77.2100,
      address: 'Ajmal Khan Road, Karol Bagh, New Delhi 110005',
      state: 'Delhi',
      district: 'West Delhi'
    },
    status: 'Submitted',
    severity: 'Medium',
    priority: 'Medium',
    department: 'Transformers & Substations',
    createdAt: formatDateOffset(0, 4),
    updatedAt: formatDateOffset(0, 4),
    aiAnalysis: {
      category: 'Power Outage',
      priority: 'Medium',
      severity: 'Medium',
      department: 'Transformers & Substations',
      summary: 'Unplanned commercial sector outage due to secondary feeder trip or circuit breaker operation.',
      safety: [
        'Unplug delicate store computer systems and electronic ledger books.',
        'Keep generator exhaust vents directed away from public windows.',
        'Avoid entering dark alleys without battery lights.'
      ],
      confidence: 93,
      duplicateDetected: false,
      engineerSummary: 'Inspect feeder circuit breaker at Karol Bagh sub-station. Check for transient overhead faults or underground cable punctures along Ajmal Khan Road.'
    }
  },
  {
    id: 'comp-10',
    ticketNumber: 'SECA-2026-0010',
    consumerId: 'CON-DL-4028492',
    consumerName: 'Rajesh Kumar',
    consumerPhone: '+91 98765 43210',
    category: 'Illegal Connection',
    description: 'Spotted some shopkeepers using hook wires (Katiya) directly on the low tension distribution cables on the poles. This causes heavy sparks at night, leads to sudden power drops, and is extremely unsafe as the wires hang low over the street.',
    location: {
      latitude: 28.6400,
      longitude: 77.1500,
      address: 'Metro Pillar 651, Uttam Nagar, New Delhi 110059',
      state: 'Delhi',
      district: 'West Delhi'
    },
    status: 'Resolved',
    severity: 'Medium',
    priority: 'Medium',
    department: 'Overhead Lines & Poles',
    engineerId: 'eng-1',
    engineerName: 'Amit Sharma',
    createdAt: formatDateOffset(4, 1),
    updatedAt: formatDateOffset(3, 4),
    resolutionTimeMinutes: 1620,
    aiAnalysis: {
      category: 'Illegal Connection',
      priority: 'Medium',
      severity: 'Medium',
      department: 'Overhead Lines & Poles',
      summary: 'Public grid power theft via unauthorized hooking, leading to phase overloading and public shock hazards.',
      safety: [
        'Do not approach or confront individuals making illegal connections.',
        'Report structural details safely via the app.',
        'Avoid standing under the pole during damp weather.'
      ],
      confidence: 92,
      duplicateDetected: false,
      engineerSummary: 'Conduct surprise raid at Pillar 651 with enforcement staff. Safely remove and confiscate copper hooks, inspect cables for core damage, install aerial bunched cables (ABC) to prevent future hooking.'
    }
  }
];

export const PRE_SEEDED_STATUS_LOGS: StatusLog[] = [
  {
    id: 'log-1',
    complaintId: 'comp-1',
    status: 'Submitted',
    updatedBy: 'usr-consumer',
    updatedByName: 'Rajesh Kumar (Consumer)',
    comments: 'Complaint registered successfully with storm damage image upload.',
    createdAt: formatDateOffset(1, 4),
  },
  {
    id: 'log-2',
    complaintId: 'comp-1',
    status: 'Acknowledged',
    updatedBy: 'usr-admin',
    updatedByName: 'Er. Sanjay Patil (Admin)',
    comments: 'System auto-classified severity to CRITICAL. Feeder 4 alerted.',
    createdAt: formatDateOffset(1, 3.5),
  },
  {
    id: 'log-3',
    complaintId: 'comp-1',
    status: 'Assigned',
    updatedBy: 'usr-admin',
    updatedByName: 'Er. Sanjay Patil (Admin)',
    comments: 'Assigned field team headed by Engineer Amit Sharma for immediate site clearing and line tensioning.',
    createdAt: formatDateOffset(1, 2),
  },
  {
    id: 'log-4',
    complaintId: 'comp-2',
    status: 'Submitted',
    updatedBy: 'system',
    updatedByName: 'AI Agent Auto-Engine',
    comments: 'Urgent consumer complaint analyzed and ingested. Critical transformer hazard flag raised.',
    createdAt: formatDateOffset(0, 5),
  },
  {
    id: 'log-5',
    complaintId: 'comp-2',
    status: 'In Progress',
    updatedBy: 'eng-2',
    updatedByName: 'Priya Nair (Engineer)',
    comments: 'Arrived at site. Substation feeder turned off. Smoke has subsided. Commencing oil-filtration check.',
    createdAt: formatDateOffset(0, 3),
  },
  {
    id: 'log-6',
    complaintId: 'comp-3',
    status: 'Submitted',
    updatedBy: 'usr-consumer',
    updatedByName: 'Arvind Singh (Consumer)',
    comments: 'Registered complaint regarding dark Sector 15 Metro Walk stretch.',
    createdAt: formatDateOffset(3, 8),
  },
  {
    id: 'log-7',
    complaintId: 'comp-3',
    status: 'Assigned',
    updatedBy: 'usr-admin',
    updatedByName: 'Er. Sanjay Patil (Admin)',
    comments: 'Assigned to Street Light Maintenance Division under Rajesh Patel.',
    createdAt: formatDateOffset(2, 4),
  },
  {
    id: 'log-8',
    complaintId: 'comp-3',
    status: 'Resolved',
    updatedBy: 'eng-4',
    updatedByName: 'Rajesh Patel (Engineer)',
    comments: 'Inspected control box. Discovered lightning had damaged the digital timer module. Replaced timer switch assembly. All 18 street lights are now functional and synchronized with solar dawn/dusk.',
    createdAt: formatDateOffset(1, 1),
  }
];

export const PRE_SEEDED_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-1',
    userId: 'usr-consumer',
    title: 'Hanging Wire Complaint Assigned',
    message: 'Your hanging wire ticket (SECA-2026-0001) has been assigned to senior engineer Amit Sharma.',
    type: 'assignment',
    isRead: false,
    createdAt: formatDateOffset(1, 2)
  },
  {
    id: 'notif-2',
    userId: 'usr-consumer',
    title: 'New Notification Service Activated',
    message: 'Welcome to SECA. You will now receive live push, SMS, and email alerts for your complaints.',
    type: 'status_update',
    isRead: true,
    createdAt: formatDateOffset(2, 0)
  }
];

// Memory storage engine with local backup in standard server file
export class DbStore {
  private complaints: Complaint[] = [...PRE_SEEDED_COMPLAINTS];
  private statusLogs: StatusLog[] = [...PRE_SEEDED_STATUS_LOGS];
  private notifications: AppNotification[] = [...PRE_SEEDED_NOTIFICATIONS];
  private engineers: Engineer[] = [...PRE_SEEDED_ENGINEERS];
  private users: User[] = [...PRE_SEEDED_USERS];

  getUsers(): User[] {
    return this.users;
  }

  getUserById(id: string): User | undefined {
    return this.users.find(u => u.id === id);
  }

  getUserByEmail(email: string): User | undefined {
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  addUser(user: User): User {
    this.users.push(user);
    return user;
  }

  getComplaints(filters?: {
    search?: string;
    category?: string;
    status?: string;
    severity?: string;
    consumerId?: string;
    engineerId?: string;
  }): Complaint[] {
    let list = [...this.complaints];

    if (filters) {
      if (filters.consumerId) {
        list = list.filter(c => c.consumerId === filters.consumerId);
      }
      if (filters.engineerId) {
        list = list.filter(c => c.engineerId === filters.engineerId);
      }
      if (filters.category) {
        list = list.filter(c => c.category === filters.category);
      }
      if (filters.status) {
        list = list.filter(c => c.status === filters.status);
      }
      if (filters.severity) {
        list = list.filter(c => c.severity === filters.severity);
      }
      if (filters.search) {
        const query = filters.search.toLowerCase();
        list = list.filter(
          c =>
            c.ticketNumber.toLowerCase().includes(query) ||
            c.description.toLowerCase().includes(query) ||
            c.consumerName.toLowerCase().includes(query) ||
            c.location.address?.toLowerCase().includes(query)
        );
      }
    }

    // Sort by newest first
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  getComplaintById(id: string): Complaint | undefined {
    return this.complaints.find(c => c.id === id);
  }

  addComplaint(complaint: Complaint): Complaint {
    this.complaints.unshift(complaint);

    // Auto log submitted status
    this.addStatusLog({
      id: `log-${Date.now()}`,
      complaintId: complaint.id,
      status: 'Submitted',
      updatedBy: complaint.consumerId,
      updatedByName: `${complaint.consumerName} (Consumer)`,
      comments: 'Complaint registered in database via SECA smart pipeline.',
      createdAt: complaint.createdAt,
    });

    // Notify administrators if critical
    if (complaint.severity === 'Critical') {
      this.addNotification({
        id: `notif-${Date.now()}`,
        userId: 'usr-admin',
        title: `CRITICAL HAZARD reported in ${complaint.location.district || 'your area'}`,
        message: `Ticket ${complaint.ticketNumber} classified as Critical: ${complaint.category}`,
        type: 'critical_hazard',
        isRead: false,
        createdAt: complaint.createdAt
      });
    }

    return complaint;
  }

  updateComplaint(id: string, updates: Partial<Complaint>, updatedBy: string, updatedByName: string): Complaint | undefined {
    const idx = this.complaints.findIndex(c => c.id === id);
    if (idx === -1) return undefined;

    const current = this.complaints[idx];
    const oldStatus = current.status;
    const oldEngineerId = current.engineerId;

    const updated = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    // If resolution details are appended
    if (updates.status === 'Resolved' && oldStatus !== 'Resolved') {
      const start = new Date(current.createdAt).getTime();
      const end = new Date().getTime();
      updated.resolutionTimeMinutes = Math.floor((end - start) / (1000 * 60));

      // Auto decrease engineer workload if assigned
      if (current.engineerId) {
        const eng = this.engineers.find(e => e.id === current.engineerId);
        if (eng) {
          eng.activeComplaintsCount = Math.max(0, eng.activeComplaintsCount - 1);
          eng.resolvedComplaintsCount += 1;
        }
      }
    }

    // If newly assigned
    if (updates.engineerId && updates.engineerId !== oldEngineerId) {
      const eng = this.engineers.find(e => e.id === updates.engineerId);
      if (eng) {
        updated.engineerName = eng.name;
        updated.department = eng.department;
        
        // Adjust workloads
        eng.activeComplaintsCount += 1;
        if (oldEngineerId) {
          const oldEng = this.engineers.find(e => e.id === oldEngineerId);
          if (oldEng) {
            oldEng.activeComplaintsCount = Math.max(0, oldEng.activeComplaintsCount - 1);
          }
        }
      }
    }

    this.complaints[idx] = updated;

    // Log status change
    if (updates.status && updates.status !== oldStatus) {
      this.addStatusLog({
        id: `log-${Date.now()}`,
        complaintId: id,
        status: updates.status,
        updatedBy,
        updatedByName,
        comments: updates.status === 'Resolved' ? 'Issues fixed on-site, service restored, safety checked.' : `Status moved to ${updates.status}.`,
        createdAt: new Date().toISOString(),
      });

      // Send push notify to consumer
      this.addNotification({
        id: `notif-${Date.now()}`,
        userId: current.consumerId,
        title: `Complaint Status Updated: ${updates.status}`,
        message: `Your ticket ${current.ticketNumber} is now ${updates.status}.`,
        type: 'status_update',
        isRead: false,
        createdAt: new Date().toISOString()
      });
    }

    return updated;
  }

  deleteComplaint(id: string): boolean {
    const len = this.complaints.length;
    this.complaints = this.complaints.filter(c => c.id !== id);
    this.statusLogs = this.statusLogs.filter(l => l.complaintId !== id);
    return this.complaints.length < len;
  }

  getStatusLogs(complaintId: string): StatusLog[] {
    return this.statusLogs
      .filter(l => l.complaintId === complaintId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  addStatusLog(log: StatusLog): StatusLog {
    this.statusLogs.push(log);
    return log;
  }

  getNotifications(userId: string): AppNotification[] {
    return this.notifications
      .filter(n => n.userId === userId || userId === 'usr-admin') // Admins see critical ones
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  addNotification(notification: AppNotification): AppNotification {
    this.notifications.unshift(notification);
    return notification;
  }

  markNotificationsAsRead(userId: string): void {
    this.notifications.forEach(n => {
      if (n.userId === userId || (userId === 'usr-admin' && n.userId === 'usr-admin')) {
        n.isRead = true;
      }
    });
  }

  getEngineers(): Engineer[] {
    return this.engineers;
  }

  getAnalyticsSummary(): AnalyticsSummary {
    const list = this.complaints;
    const total = list.length;
    const pending = list.filter(c => c.status !== 'Resolved' && c.status !== 'Closed').length;
    const resolved = list.filter(c => c.status === 'Resolved' || c.status === 'Closed').length;
    const critical = list.filter(c => c.severity === 'Critical' && c.status !== 'Resolved' && c.status !== 'Closed').length;

    // Today's count
    const today = new Date().toISOString().split('T')[0];
    const todayCount = list.filter(c => c.createdAt.split('T')[0] === today).length;

    // Distribution
    const categoryDistribution: Record<string, number> = {};
    const severityDistribution: Record<string, number> = {};
    const statusDistribution: Record<string, number> = {};

    list.forEach(c => {
      categoryDistribution[c.category] = (categoryDistribution[c.category] || 0) + 1;
      severityDistribution[c.severity] = (severityDistribution[c.severity] || 0) + 1;
      statusDistribution[c.status] = (statusDistribution[c.status] || 0) + 1;
    });

    // Daily Trends (last 5 days)
    const dailyTrends = Array.from({ length: 5 }, (_, i) => {
      const d = new Date(baseDate);
      d.setDate(d.getDate() - i);
      const dateStr = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
      const isoDate = d.toISOString().split('T')[0];

      const submitted = list.filter(c => c.createdAt.split('T')[0] === isoDate).length;
      const res = list.filter(c => {
        return (c.status === 'Resolved' || c.status === 'Closed') && c.updatedAt.split('T')[0] === isoDate;
      }).length;

      return { date: dateStr, submitted, resolved: res };
    }).reverse();

    // Resolution Time trend (last 5 days)
    const resolutionTimeTrend = Array.from({ length: 5 }, (_, i) => {
      const d = new Date(baseDate);
      d.setDate(d.getDate() - i);
      const dateStr = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
      const isoDate = d.toISOString().split('T')[0];

      const resWithTimes = list.filter(
        c => (c.status === 'Resolved' || c.status === 'Closed') &&
             c.updatedAt.split('T')[0] === isoDate &&
             c.resolutionTimeMinutes !== undefined
      );

      const totalTime = resWithTimes.reduce((acc, curr) => acc + (curr.resolutionTimeMinutes || 0), 0);
      const avgTimeMinutes = resWithTimes.length > 0 ? Math.round(totalTime / resWithTimes.length) : 0;

      return { date: dateStr, avgTimeMinutes };
    }).reverse();

    return {
      total,
      pending,
      resolved,
      critical,
      todayCount,
      categoryDistribution,
      severityDistribution,
      statusDistribution,
      dailyTrends,
      resolutionTimeTrend,
    };
  }
}

// Instantiate global database store
export const dbStore = new DbStore();
