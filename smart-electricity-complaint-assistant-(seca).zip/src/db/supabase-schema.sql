-- ====================================================
-- SMART ELECTRICITY COMPLAINT ASSISTANT (SECA)
-- SUPABASE POSTGRESQL PRODUCTION DATABASE SCHEMA
-- ====================================================

-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- Create ENUM types
create type user_role as enum ('consumer', 'engineer', 'admin');
create type complaint_status as enum ('Submitted', 'Acknowledged', 'Assigned', 'In Progress', 'Resolved', 'Closed');
create type severity_level as enum ('Low', 'Medium', 'High', 'Critical');
create type priority_level as enum ('Low', 'Medium', 'High', 'Immediate');
create type notification_type as enum ('status_update', 'assignment', 'critical_hazard', 'billing');

-- 1. USERS TABLE
create table public.users (
  id uuid references auth.users on delete cascade primary key,
  name text not null,
  email text unique not null,
  phone text not null,
  role user_role not null default 'consumer',
  avatar_url text,
  consumer_id text unique,
  state text not null default 'Delhi',
  district text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. ENGINEERS TABLE
create table public.engineers (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  phone text not null,
  department text not null,
  status text not null default 'Active',
  active_complaints_count integer default 0 not null,
  resolved_complaints_count integer default 0 not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. COMPLAINTS TABLE
create table public.complaints (
  id uuid primary key default uuid_generate_v4(),
  ticket_number text unique not null,
  consumer_id text not null,
  consumer_name text not null,
  consumer_phone text not null,
  category text not null,
  description text not null,
  latitude double precision,
  longitude double precision,
  address text,
  state text not null,
  district text not null,
  image_url text,
  voice_url text,
  status complaint_status default 'Submitted' not null,
  severity severity_level default 'Medium' not null,
  priority priority_level default 'Medium' not null,
  department text not null,
  engineer_id uuid references public.engineers(id) on delete set null,
  ai_analysis jsonb,
  resolution_time_minutes integer,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. STATUS LOGS TABLE
create table public.status_logs (
  id uuid primary key default uuid_generate_v4(),
  complaint_id uuid references public.complaints(id) on delete cascade not null,
  status complaint_status not null,
  updated_by uuid not null,
  updated_by_name text not null,
  comments text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 5. NOTIFICATIONS TABLE
create table public.notifications (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null,
  title text not null,
  message text not null,
  type notification_type not null,
  is_read boolean default false not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- ====================================================
-- INDEXES FOR HIGH-SPEED QUERY OPTIMIZATION
-- ====================================================
create index idx_complaints_consumer_id on public.complaints(consumer_id);
create index idx_complaints_engineer_id on public.complaints(engineer_id);
create index idx_complaints_status on public.complaints(status);
create index idx_complaints_severity on public.complaints(severity);
create index idx_status_logs_complaint_id on public.status_logs(complaint_id);
create index idx_notifications_user_id on public.notifications(user_id);

-- ====================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================
alter table public.users enable row level security;
alter table public.complaints enable row level security;
alter table public.status_logs enable row level security;
alter table public.notifications enable row level security;

-- USERS POLICIES
create policy "Allow public read-access for profiles"
  on public.users for select
  using (true);

create policy "Allow users to update their own profiles"
  on public.users for update
  using (auth.uid() = id);

-- COMPLAINTS POLICIES
create policy "Consumers can read their own complaints"
  on public.complaints for select
  using (auth.role() = 'authenticated' and (consumer_id = auth.jwt() ->> 'consumer_id' or auth.jwt() ->> 'role' in ('engineer', 'admin')));

create policy "Consumers can insert complaints"
  on public.complaints for insert
  with check (auth.role() = 'authenticated');

create policy "Admins and Engineers can update complaints"
  on public.complaints for update
  using (auth.jwt() ->> 'role' in ('engineer', 'admin'));

-- NOTIFICATIONS POLICIES
create policy "Users can read their own notifications"
  on public.notifications for select
  using (auth.uid() = user_id or auth.jwt() ->> 'role' = 'admin');

-- ====================================================
-- TRIGGERS & PROCEDURES (AUTOMATIC STATUS LOGGING)
-- ====================================================

-- Function to record status changes inside status_logs automatically
create or replace function public.log_complaint_status_change()
returns trigger as $$
begin
  if (TG_OP = 'INSERT') then
    insert into public.status_logs (complaint_id, status, updated_by, updated_by_name, comments)
    values (NEW.id, NEW.status, NEW.id, NEW.consumer_name, 'Complaint logged in grid database.');
  elsif (TG_OP = 'UPDATE' and OLD.status <> NEW.status) then
    insert into public.status_logs (complaint_id, status, updated_by, updated_by_name, comments)
    values (NEW.id, NEW.status, NEW.id, 'System Dispatcher', concat('Status moved from ', OLD.status, ' to ', NEW.status));
  end if;
  return NEW;
end;
$$ language plpgsql;

create trigger trigger_complaint_status_change
  after insert or update of status on public.complaints
  for each row execute procedure public.log_complaint_status_change();
