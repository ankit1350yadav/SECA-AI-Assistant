import { StatusLog, ComplaintStatus } from '../types';
import { CheckCircle2, Clock, Hammer, ShieldAlert, UserCheck, HelpCircle } from 'lucide-react';

interface TimelineProps {
  logs: StatusLog[];
}

export default function ComplaintTimeline({ logs }: TimelineProps) {
  const getStatusIcon = (status: ComplaintStatus) => {
    switch (status) {
      case 'Submitted':
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500 text-white ring-8 ring-blue-50 dark:ring-blue-950/20">
            <Clock className="h-4 w-4" />
          </div>
        );
      case 'Acknowledged':
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-500 text-white ring-8 ring-amber-50 dark:ring-amber-950/20">
            <HelpCircle className="h-4 w-4" />
          </div>
        );
      case 'Assigned':
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-500 text-white ring-8 ring-indigo-50 dark:ring-indigo-950/20">
            <UserCheck className="h-4 w-4" />
          </div>
        );
      case 'In Progress':
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-yellow-500 text-white ring-8 ring-yellow-50 dark:ring-yellow-950/20 animate-pulse">
            <Hammer className="h-4 w-4" />
          </div>
        );
      case 'Resolved':
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-white ring-8 ring-emerald-50 dark:ring-emerald-950/20">
            <CheckCircle2 className="h-4 w-4" />
          </div>
        );
      case 'Closed':
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-600 text-white ring-8 ring-slate-100 dark:ring-slate-800">
            <CheckCircle2 className="h-4 w-4" />
          </div>
        );
      default:
        return (
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-400 text-white ring-8 ring-slate-100">
            <Clock className="h-4 w-4" />
          </div>
        );
    }
  };

  const sortedLogs = [...logs].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
      <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
        <Clock className="h-5 w-5 text-saffron" />
        <h3 className="text-sm sm:text-base font-bold text-slate-800 dark:text-white">
          Complaint Audit Timeline
        </h3>
      </div>

      {sortedLogs.length === 0 ? (
        <p className="text-xs text-slate-400 text-center py-6">No logs have been registered yet.</p>
      ) : (
        <div className="relative border-l border-slate-200 dark:border-slate-800 ml-4 pl-6 space-y-8 py-3">
          {sortedLogs.map((log) => (
            <div key={log.id} className="relative">
              {/* Bullet point icon */}
              <span className="absolute -left-[38px] top-0.5">
                {getStatusIcon(log.status)}
              </span>

              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 rounded-md">
                    {log.status}
                  </span>
                  <span className="text-[11px] text-slate-400 dark:text-slate-500 font-mono">
                    {new Date(log.createdAt).toLocaleString('en-IN', {
                      day: '2-digit',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
                  {log.comments}
                </p>

                <div className="flex items-center gap-1.5 text-[10px] text-slate-400 dark:text-slate-500">
                  <span className="font-bold text-saffron font-mono">UPDATED BY:</span>
                  <span className="font-semibold">{log.updatedByName}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
