import { useState } from 'react';
import { MapPin, Navigation, Map, Globe, Compass, AlertCircle } from 'lucide-react';
import { LocationData } from '../types';

interface LocationPickerProps {
  onLocationSelected: (location: LocationData) => void;
  initialLocation?: LocationData;
}

export default function LocationPicker({ onLocationSelected, initialLocation }: LocationPickerProps) {
  const [loading, setLoading] = useState(false);
  const [coords, setCoords] = useState<{ lat?: number; lng?: number }>({
    lat: initialLocation?.latitude || 28.6139,
    lng: initialLocation?.longitude || 77.2090,
  });
  const [address, setAddress] = useState(initialLocation?.address || '');
  const [state, setState] = useState(initialLocation?.state || 'Delhi');
  const [district, setDistrict] = useState(initialLocation?.district || 'West Delhi');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const detectLocation = () => {
    setLoading(true);
    setErrorMsg(null);

    if (!navigator.geolocation) {
      setErrorMsg('Geolocation is not supported by your browser.');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setCoords({ lat: latitude, lng: longitude });

        // Simulated high-fidelity Indian reverse geocoding
        const mockAddresses = [
          {
            addr: 'Pocket B, Sector 18, Dwarka, New Delhi, Delhi 110075',
            dist: 'West Delhi',
            st: 'Delhi',
          },
          {
            addr: '12th Main Road, Hal 2nd Stage, Indiranagar, Bengaluru, Karnataka 560038',
            dist: 'Bengaluru Urban',
            st: 'Karnataka',
          },
          {
            addr: 'Bandra Reclamation, Bandra West, Mumbai, Maharashtra 400050',
            dist: 'Mumbai Suburban',
            st: 'Maharashtra',
          },
        ];

        // Pick one randomly or use Dwarka as Delhi is our default seed zone
        const resolved = mockAddresses[Math.floor(Math.random() * mockAddresses.length)];
        setAddress(resolved.addr);
        setDistrict(resolved.dist);
        setState(resolved.st);

        onLocationSelected({
          latitude,
          longitude,
          address: resolved.addr,
          district: resolved.dist,
          state: resolved.st,
        });

        setLoading(false);
      },
      (error) => {
        console.error('GPS error:', error);
        setErrorMsg('Unable to retrieve your location. Utilizing default regional grid.');
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  const handleManualChange = (field: string, val: string) => {
    let updatedLocation: LocationData = {
      latitude: coords.lat,
      longitude: coords.lng,
      address,
      state,
      district,
    };

    if (field === 'address') {
      setAddress(val);
      updatedLocation.address = val;
    } else if (field === 'state') {
      setState(val);
      updatedLocation.state = val;
    } else if (field === 'district') {
      setDistrict(val);
      updatedLocation.district = val;
    }

    onLocationSelected(updatedLocation);
  };

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Map className="h-5 w-5 text-saffron" />
          <h4 className="text-sm font-semibold text-slate-800 dark:text-white">GPS Grid Location</h4>
        </div>
        <span className="text-[10px] font-mono font-bold text-slate-400 dark:text-slate-500">
          GIS Lat-Long
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Detection Button & Address form */}
        <div className="space-y-3.5">
          <button
            type="button"
            onClick={detectLocation}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 py-3 text-xs font-bold border border-slate-200 dark:border-slate-700/80 transition-all active:scale-[0.98]"
          >
            <Navigation className={`h-4 w-4 text-saffron ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'ACQUIRING SATELLITE LOCK...' : 'AUTO-DETECT MY GPS POSITION'}</span>
          </button>

          {errorMsg && (
            <div className="flex gap-1.5 p-2 rounded-lg bg-amber-50 dark:bg-amber-950/10 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
              <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
              Landmark / Street Address
            </label>
            <textarea
              value={address}
              onChange={(e) => handleManualChange('address', e.target.value)}
              placeholder="e.g. Pillar No. 120, Opp Metro Station, Karol Bagh"
              className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-xs text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden leading-relaxed"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                State
              </label>
              <input
                type="text"
                value={state}
                onChange={(e) => handleManualChange('state', e.target.value)}
                placeholder="e.g. Delhi"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-xs text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                District / Division
              </label>
              <input
                type="text"
                value={district}
                onChange={(e) => handleManualChange('district', e.target.value)}
                placeholder="e.g. West Delhi"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-xs text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Dynamic Vector Radar Map Preview */}
        <div className="relative rounded-xl border border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-950 overflow-hidden flex flex-col items-center justify-center p-4 min-h-[180px]">
          {/* Radar grids */}
          <div className="absolute inset-0 opacity-10 dark:opacity-20 flex items-center justify-center pointer-events-none">
            <div className="absolute border border-slate-500 rounded-full h-12 w-12 animate-pulse"></div>
            <div className="absolute border border-slate-500 rounded-full h-24 w-24"></div>
            <div className="absolute border border-slate-500 rounded-full h-40 w-40"></div>
            <div className="absolute border-l border-slate-500 h-full w-0"></div>
            <div className="absolute border-t border-slate-500 w-full h-0"></div>
          </div>

          <div className="relative z-10 flex flex-col items-center text-center space-y-1.5">
            <div className="relative">
              <MapPin className="h-8 w-8 text-saffron animate-bounce" />
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5 rounded-full bg-red-500 animate-ping"></span>
            </div>
            <p className="text-xs font-bold text-slate-700 dark:text-slate-200 leading-tight">
              Grid Radar Locked
            </p>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 dark:text-slate-500 bg-white/60 dark:bg-slate-900/60 px-2 py-0.5 rounded-md border border-slate-100 dark:border-slate-800">
              <Compass className="h-3.5 w-3.5 text-govblue" />
              <span>LAT: {coords.lat?.toFixed(5)}</span>
              <span>•</span>
              <span>LNG: {coords.lng?.toFixed(5)}</span>
            </div>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 italic px-2 max-w-[200px] truncate leading-tight">
              {address || 'Awaiting coordinates lock...'}
            </span>
          </div>

          <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-saffron/10 text-saffron text-[9px] font-bold px-1.5 py-0.5 rounded border border-saffron/20 uppercase tracking-widest font-mono">
            <Globe className="h-3 w-3 animate-spin" />
            <span>GIS Map</span>
          </div>
        </div>
      </div>
    </div>
  );
}
