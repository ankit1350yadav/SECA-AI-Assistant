import { useState, useRef, useEffect } from 'react';
import { Mic, Square, Play, Trash2, Check, RefreshCw, AudioLines } from 'lucide-react';

interface VoiceRecorderProps {
  onTranscriptReceived: (transcript: string, audioUrl: string) => void;
  authToken?: string;
}

export default function VoiceRecorder({ onTranscriptReceived, authToken }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>('');
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const animationFrameRef = useRef<number | null>(null);
  const [waveHeight, setWaveHeight] = useState<number[]>([12, 24, 18, 32, 10, 16, 22, 14]);

  // Cleanup URLs on unmount
  useEffect(() => {
    return () => {
      if (audioUrl && audioUrl.startsWith('blob:')) {
        URL.revokeObjectURL(audioUrl);
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [audioUrl]);

  // Simulate waveforms during recording
  const animateWave = () => {
    if (!isRecording) return;
    setWaveHeight(Array.from({ length: 12 }, () => Math.floor(10 + Math.random() * 40)));
    animationFrameRef.current = requestAnimationFrame(animateWave);
  };

  const startRecording = async () => {
    audioChunksRef.current = [];
    setErrorMessage(null);
    setTranscript('');

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
        
        // Stop all track streams to release microphone
        stream.getTracks().forEach((track) => track.stop());

        // Automatically trigger AI transcription
        transcribeAudio(audioBlob, url);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setTimeout(() => {
        // start animation loop
        animateWave();
      }, 50);
    } catch (err: any) {
      console.error('Mic permission error:', err);
      setErrorMessage('Microphone access denied or unsupported. Please check browser permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }
  };

  const transcribeAudio = async (blob: Blob, blobUrl: string) => {
    setIsTranscribing(true);
    setErrorMessage(null);

    try {
      // Convert audio blob to base64 for server submission
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Data = reader.result as string;
        const pureBase64 = base64Data.split(',')[1];

        const response = await fetch('/api/voice', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: authToken ? `Bearer ${authToken}` : '',
          },
          body: JSON.stringify({ voiceBase64: pureBase64 }),
        });

        if (!response.ok) {
          throw new Error('Server returned failure for voice processing.');
        }

        const data = await response.json();
        setTranscript(data.transcript);
        onTranscriptReceived(data.transcript, blobUrl);
      };
    } catch (err: any) {
      console.error('Transcription failed:', err);
      setErrorMessage('AI voice transcription encountered a slight issue. You can still describe the issue manually.');
    } finally {
      setIsTranscribing(false);
    }
  };

  const deleteRecording = () => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    setAudioUrl(null);
    setTranscript('');
    setErrorMessage(null);
  };

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <AudioLines className="h-5 w-5 text-saffron" />
          <h4 className="text-sm font-semibold text-slate-800 dark:text-white">Voice Reporting Pipeline</h4>
        </div>
        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono">
          AI Transcriber Ready
        </span>
      </div>

      <div className="flex flex-col items-center justify-center py-6 space-y-4">
        {/* Animated Microphone Area */}
        {isRecording ? (
          <div className="flex flex-col items-center space-y-4">
            <div className="flex items-center justify-center gap-1.5 h-12">
              {waveHeight.map((h, i) => (
                <span
                  key={i}
                  style={{ height: `${h}px` }}
                  className="w-1 rounded-full bg-saffron transition-all duration-100"
                ></span>
              ))}
            </div>
            <button
              id="btn-stop-recording"
              onClick={stopRecording}
              className="flex h-14 w-14 items-center justify-center rounded-full bg-red-500 hover:bg-red-600 text-white shadow-lg pulse-hazard transition-transform transform active:scale-95"
              title="Stop Recording"
            >
              <Square className="h-5 w-5" />
            </button>
            <span className="text-xs font-semibold text-red-500 animate-pulse font-mono">
              RECORDING LIVE WIRELESS AUDIO...
            </span>
          </div>
        ) : audioUrl ? (
          <div className="w-full flex flex-col items-center space-y-3">
            <audio src={audioUrl} controls className="w-full max-w-sm h-10 accent-saffron" />
            
            <div className="flex gap-2">
              <button
                type="button"
                onClick={deleteRecording}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 dark:border-red-950/40 text-xs font-bold text-red-500 hover:bg-red-50 dark:hover:bg-red-950/15 transition-all"
              >
                <Trash2 className="h-4 w-4" />
                <span>Delete</span>
              </button>
              
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                  transcribeAudio(blob, audioUrl);
                }}
                disabled={isTranscribing}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all disabled:opacity-50"
              >
                <RefreshCw className={`h-4 w-4 ${isTranscribing ? 'animate-spin' : ''}`} />
                <span>Retry STT</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center space-y-3">
            <button
              id="btn-start-recording"
              type="button"
              onClick={startRecording}
              className="flex h-14 w-14 items-center justify-center rounded-full bg-linear-to-tr from-saffron to-govblue text-white shadow-md hover:opacity-90 active:scale-95 transition-all"
              title="Start Voice complaint"
            >
              <Mic className="h-6 w-6" />
            </button>
            <p className="text-xs text-slate-500 dark:text-slate-400 text-center">
              Speak in Hindi, English, or regional language.<br />Our AI detects sparks, fire, power-cuts, and parses it.
            </p>
          </div>
        )}

        {/* Live Transcription Box */}
        {isTranscribing && (
          <div className="w-full flex items-center justify-center gap-2 py-4 text-xs font-medium text-slate-500">
            <RefreshCw className="h-4 w-4 animate-spin text-saffron" />
            <span>AI model is transcribing voice to text...</span>
          </div>
        )}

        {transcript && (
          <div className="w-full p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/40">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 mb-1">
              <Check className="h-4 w-4" />
              <span>AI Speech-to-Text Transcript</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 italic leading-relaxed">
              "{transcript}"
            </p>
          </div>
        )}

        {errorMessage && (
          <p className="text-xs font-semibold text-red-500 text-center">
            {errorMessage}
          </p>
        )}
      </div>
    </div>
  );
}
