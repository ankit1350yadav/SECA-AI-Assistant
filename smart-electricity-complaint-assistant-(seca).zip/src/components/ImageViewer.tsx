import React, { useState, useRef, ChangeEvent, DragEvent, MouseEvent } from 'react';
import { Camera, Upload, X, Eye, Image as ImageIcon } from 'lucide-react';

interface ImageViewerProps {
  onImageCaptured: (base64Image: string) => void;
  initialImage?: string;
}

export default function ImageViewer({ onImageCaptured, initialImage }: ImageViewerProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(initialImage || null);
  const [isDragging, setIsDragging] = useState(false);
  const [showLightbox, setShowLightbox] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file.');
      return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => {
      const base64Data = reader.result as string;
      setPreviewUrl(base64Data);
      onImageCaptured(base64Data);
    };
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const triggerSelectFile = () => {
    fileInputRef.current?.click();
  };

  const removeImage = (e: MouseEvent) => {
    e.stopPropagation();
    setPreviewUrl(null);
    onImageCaptured('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-3">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {previewUrl ? (
        <div className="relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 max-h-64 flex items-center justify-center">
          <img
            src={previewUrl}
            alt="Complaint Incident Preview"
            className="w-full h-auto max-h-64 object-contain"
            referrerPolicy="no-referrer"
          />
          
          {/* Action Overlay */}
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-3 transition-opacity duration-200">
            <button
              type="button"
              onClick={() => setShowLightbox(true)}
              className="p-2 bg-white/25 rounded-lg text-white hover:bg-white/40 backdrop-blur-xs transition-colors"
              title="Inspect Photo"
            >
              <Eye className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={removeImage}
              className="p-2 bg-red-500/80 rounded-lg text-white hover:bg-red-500 backdrop-blur-xs transition-colors"
              title="Remove Photo"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      ) : (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={triggerSelectFile}
          className={`flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 ${
            isDragging
              ? 'border-saffron bg-saffron/5 dark:bg-saffron/10'
              : 'border-slate-200 hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/20'
          }`}
        >
          <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 mb-3 group-hover:scale-105 transition-transform">
            <Upload className="h-5 w-5" />
          </div>
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            Drag & drop images here, or <span className="text-saffron">browse files</span>
          </p>
          <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
            Supports PNG, JPG, or WEBP up to 10MB.<br />Our AI Vision model classifies damage details automatically.
          </p>
        </div>
      )}

      {/* Lightbox Modal */}
      {showLightbox && previewUrl && (
        <div
          onClick={() => setShowLightbox(false)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-fade-in"
        >
          <button
            onClick={() => setShowLightbox(false)}
            className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
            title="Close Lightbox"
          >
            <X className="h-6 w-6" />
          </button>
          <img
            src={previewUrl}
            alt="Enlarged Hazard Detail"
            className="max-w-full max-h-[90vh] rounded-lg shadow-2xl object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
      )}
    </div>
  );
}
