import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Sparkles, AlertCircle, HelpCircle, ShieldAlert } from 'lucide-react';
import { SupportedLanguage, translations } from '../lib/translations.js';

interface AIChatbotProps {
  lang: SupportedLanguage;
  token: string;
  onAutoFillDraft: (category: string, description: string) => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export default function AIChatbot({ lang, token, onAutoFillDraft }: AIChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const t = (key: string): string => translations[lang]?.[key] || translations['en']?.[key] || key;

  useEffect(() => {
    // Add default welcome message
    setMessages([
      {
        id: 'welcome',
        role: 'bot',
        text: t('chatWelcome'),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  }, [lang]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    try {
      // Build brief history context
      const history = messages.map(m => ({ role: m.role, text: m.text }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token ? `Bearer ${token}` : ''
        },
        body: JSON.stringify({ message: textToSend, history })
      });

      if (!res.ok) throw new Error('API server unreachable');
      const data = await res.json();

      const botMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'bot',
        text: data.text || 'I am processing your request.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (e) {
      const errorMsg: ChatMessage = {
        id: `msg-err-${Date.now()}`,
        role: 'bot',
        text: 'Sorry, I am facing connectivity issues. Please try again or submit your complaint directly.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleFAQClick = (faqText: string) => {
    handleSendMessage(faqText);
  };

  // Helper to extract JSON data from chatbot auto-fill string if present
  const extractAutoFillData = (text: string) => {
    const match = text.match(/\[AUTO_FILL:\s*(\{.*?\})\s*\]/);
    if (match && match[1]) {
      try {
        return JSON.parse(match[1]);
      } catch (e) {
        return null;
      }
    }
    return null;
  };

  const cleanBotMessageText = (text: string) => {
    return text.replace(/\[AUTO_FILL:\s*\{.*?\}\s*\]/g, '').trim();
  };

  const currentFAQs = [
    { label: "💳 Bill Slab Rates", text: "What are the slab rates for my electricity bill?" },
    { label: "🔥 Sparks & Smoke", text: "There are sparks coming out of the street transformer" },
    { label: "⚡ Low Voltage", text: "My house is experiencing very low voltage, fans are moving slowly" },
    { label: "🌧️ Monsoon Safety", text: "What are safety rules for metallic poles in heavy rain?" }
  ];

  return (
    <>
      {/* Floating Trigger Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-linear-to-tr from-saffron to-govblue text-white shadow-2xl focus:outline-hidden relative"
          id="seca-chatbot-trigger"
        >
          {isOpen ? <X className="h-6 w-6" /> : <MessageSquare className="h-6 w-6" />}
          {!isOpen && (
            <span className="absolute -top-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-saffron opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-saffron text-[9px] font-bold text-slate-900 justify-center items-center">1</span>
            </span>
          )}
        </motion.button>
      </div>

      {/* Chat Window Popup */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            className="fixed bottom-24 right-6 z-50 w-full max-w-sm overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl flex flex-col h-[520px] md:max-w-md"
            id="seca-chatbot-panel"
          >
            {/* Header */}
            <div className="bg-linear-to-r from-slate-950 via-slate-900 to-slate-950 px-4 py-3.5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-saffron/10 flex items-center justify-center text-saffron">
                  <Sparkles className="h-5 w-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white tracking-wide">{t('chatTitle')}</h3>
                  <span className="text-[9px] font-mono text-ashgreen flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-ashgreen animate-pulse inline-block" />
                    Gemini 3.5 Active
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-all"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Chat Body messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50 dark:bg-slate-950/20">
              {messages.map((msg) => {
                const autoFillData = msg.role === 'bot' ? extractAutoFillData(msg.text) : null;
                const cleanText = msg.role === 'bot' ? cleanBotMessageText(msg.text) : msg.text;

                return (
                  <div key={msg.id} className="space-y-2">
                    <div className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs shadow-xs leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-govblue text-white rounded-br-none'
                            : 'bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{cleanText}</p>
                        <span className="block text-[9px] text-right mt-1 opacity-60 font-mono">
                          {msg.timestamp}
                        </span>
                      </div>
                    </div>

                    {/* Auto Fill smart interactive card prompt */}
                    {autoFillData && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="mx-2 p-3.5 rounded-xl border border-saffron/30 bg-linear-to-tr from-saffron/5 to-white dark:to-slate-900 shadow-md space-y-2.5"
                      >
                        <div className="flex items-start gap-2">
                          <ShieldAlert className="h-4 w-4 text-saffron shrink-0 mt-0.5" />
                          <div>
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                              SECA Smart Extraction
                            </span>
                            <h4 className="text-xs font-extrabold text-slate-800 dark:text-white">
                              Auto-Draft complaint ticket?
                            </h4>
                          </div>
                        </div>

                        <div className="p-2 rounded bg-slate-50 dark:bg-slate-800/60 text-[11px] space-y-1 border border-slate-100 dark:border-slate-800">
                          <p className="text-[10px] text-slate-400 font-mono uppercase">
                            Category: <strong className="text-saffron">{autoFillData.category}</strong>
                          </p>
                          <p className="text-slate-600 dark:text-slate-300 italic">
                            "{autoFillData.description}"
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            onAutoFillDraft(autoFillData.category, autoFillData.description);
                            setIsOpen(false);
                          }}
                          className="w-full py-2 rounded-lg bg-saffron text-slate-900 font-bold text-[11px] text-center shadow-xs active:scale-95 hover:bg-opacity-90 transition-all uppercase"
                        >
                          ⚡ Auto-Fill File Complaint Form
                        </button>
                      </motion.div>
                    )}
                  </div>
                );
              })}

              {/* Typing bubbles */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-800 rounded-2xl rounded-bl-none px-4 py-3 flex gap-1 items-center">
                    <span className="h-1.5 w-1.5 rounded-full bg-saffron animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-saffron animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-saffron animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>

            {/* Quick FAQs Suggestion bar */}
            {messages.length === 1 && (
              <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
                <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                  Frequently Asked Questions
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {currentFAQs.map((faq, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleFAQClick(faq.text)}
                      className="text-left p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-800 hover:border-saffron/40 transition-all text-[10px] font-medium text-slate-700 dark:text-slate-300 leading-snug shadow-2xs truncate"
                    >
                      {faq.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Footer form */}
            <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage(inputVal);
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  placeholder="Ask a question..."
                  className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3.5 py-2 text-xs text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                />
                <button
                  type="submit"
                  disabled={!inputVal.trim() || isTyping}
                  className="rounded-xl bg-linear-to-tr from-saffron to-govblue text-white p-2 shrink-0 active:scale-95 transition-all shadow-md disabled:opacity-40"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
