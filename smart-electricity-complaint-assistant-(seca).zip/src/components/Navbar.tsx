import { useState } from 'react';
import { User, AppNotification } from '../types';
import { Bell, Sun, Moon, LogOut, CheckCircle, Shield, AlertTriangle, FileText, User as UserIcon, Globe, Wifi, WifiOff } from 'lucide-react';
import { SupportedLanguage, LANGUAGES } from '../lib/translations.js';

interface NavbarProps {
  user: User | null;
  notifications: AppNotification[];
  onMarkNotificationsAsRead: () => void;
  onLogout: () => void;
  onNavigateToProfile: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  lang: SupportedLanguage;
  onLangChange: (lang: SupportedLanguage) => void;
  isOnline: boolean;
}

export default function Navbar({
  user,
  notifications,
  onMarkNotificationsAsRead,
  onLogout,
  onNavigateToProfile,
  darkMode,
  onToggleDarkMode,
  lang,
  onLangChange,
  isOnline,
}: NavbarProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleNotificationClick = () => {
    setShowNotifications(!showNotifications);
    if (!showNotifications && unreadCount > 0) {
      onMarkNotificationsAsRead();
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'critical_hazard':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'assignment':
        return <Shield className="h-5 w-5 text-blue-500" />;
      case 'status_update':
        return <CheckCircle className="h-5 w-5 text-emerald-500" />;
      default:
        return <FileText className="h-5 w-5 text-amber-500" />;
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md transition-colors duration-200">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Logo */}
        <div className="flex items-center gap-3 cursor-pointer">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-linear-to-tr from-saffron to-ashgreen p-0.5 shadow-md">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-white dark:bg-slate-950">
              <span className="font-display text-xl font-bold text-govblue dark:text-saffron">⚡</span>
            </div>
            {/* National Chakra Dot */}
            <span className="absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-2 border-white dark:border-slate-950 bg-govblue"></span>
          </div>
          <div>
            <span className="font-display text-lg font-bold tracking-tight text-slate-800 dark:text-white sm:block">
              SECA <span className="text-xs font-semibold text-saffron font-sans">INDIA</span>
            </span>
            <p className="hidden text-[10px] font-medium text-slate-400 dark:text-slate-500 sm:block leading-none">
              Smart Electricity Complaint Assistant
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* PWA Connection Status Badge */}
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide font-mono ${
            isOnline 
              ? 'bg-emerald-50 text-emerald-600 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/20' 
              : 'bg-amber-50 text-amber-600 border border-amber-100 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900/20'
          }`}>
            {isOnline ? (
              <>
                <Wifi className="h-3 w-3" />
                <span className="hidden sm:inline">ONLINE</span>
              </>
            ) : (
              <>
                <WifiOff className="h-3 w-3 animate-pulse" />
                <span>OFFLINE (PWA)</span>
              </>
            )}
          </div>

          {/* Multilingual Selector dropdown */}
          <div className="relative flex items-center gap-1">
            <Globe className="h-4 w-4 text-slate-400 dark:text-slate-500" />
            <select
              value={lang}
              onChange={(e) => onLangChange(e.target.value as SupportedLanguage)}
              className="bg-transparent text-xs font-bold text-slate-700 dark:text-slate-300 border-none outline-hidden focus:ring-0 cursor-pointer max-w-[90px] sm:max-w-none"
              title="Change Language"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100">
                  {l.name}
                </option>
              ))}
            </select>
          </div>

          {/* Light/Dark Toggle */}
          <button
            id="btn-theme-toggle"
            onClick={onToggleDarkMode}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
            title="Toggle theme"
          >
            {darkMode ? <Sun className="h-5 w-5 text-amber-400" /> : <Moon className="h-5 w-5 text-slate-700" />}
          </button>

          {user && (
            <>
              {/* Notifications Panel Trigger */}
              <div className="relative">
                <button
                  id="btn-notifications"
                  onClick={handleNotificationClick}
                  className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
                  title="View Notifications"
                >
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white leading-none">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2 shadow-xl animate-fade-in z-50">
                    <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2 mb-2 px-2">
                      <span className="text-sm font-semibold text-slate-800 dark:text-white">Alert Notifications</span>
                      {unreadCount > 0 && (
                        <span className="text-xs font-medium text-saffron">New updates pending</span>
                      )}
                    </div>
                    <div className="max-h-72 overflow-y-auto no-scrollbar space-y-1">
                      {notifications.length === 0 ? (
                        <div className="py-8 text-center text-xs text-slate-400 dark:text-slate-500">
                          No recent alerts.
                        </div>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif.id}
                            className={`flex gap-3 rounded-lg p-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors ${
                              !notif.isRead ? 'bg-slate-50/60 dark:bg-slate-800/40' : ''
                            }`}
                          >
                            <div className="mt-0.5 shrink-0">{getNotificationIcon(notif.type)}</div>
                            <div className="space-y-0.5">
                              <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 leading-tight">
                                {notif.title}
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
                                {notif.message}
                              </p>
                              <span className="text-[9px] text-slate-400 dark:text-slate-500 font-mono">
                                {new Date(notif.createdAt).toLocaleTimeString('en-IN', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* User Account Capsule */}
              <div className="flex items-center gap-2 border-l border-slate-200 dark:border-slate-800 pl-4">
                <button
                  id="btn-user-profile"
                  onClick={onNavigateToProfile}
                  className="flex items-center gap-2 rounded-xl p-1 text-left hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
                >
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      className="h-8 w-8 rounded-lg object-cover ring-2 ring-saffron/20"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-linear-to-tr from-saffron/20 to-govblue/20 text-govblue dark:text-saffron">
                      <UserIcon className="h-4 w-4" />
                    </div>
                  )}
                  <div className="hidden md:block">
                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 leading-tight truncate max-w-[100px]">
                      {user.name}
                    </p>
                    <span className="text-[10px] font-bold text-saffron uppercase font-mono tracking-wider leading-none">
                      {user.role}
                    </span>
                  </div>
                </button>

                {/* Logout Button */}
                <button
                  id="btn-logout"
                  onClick={onLogout}
                  className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-950/20 transition-colors"
                  title="Logout"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
