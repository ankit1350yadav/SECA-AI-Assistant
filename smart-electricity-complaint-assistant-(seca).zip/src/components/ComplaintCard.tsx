import React from 'react';
import { Complaint } from '../types';
import { MapPin, Calendar, Shield, AlertTriangle, ArrowRight, Phone, MessageSquare, Clock } from 'lucide-react';

interface ComplaintCardProps {
  key?: string | number;
  complaint: Complaint;
  onViewDetails: (id: string) => void;
  showAssignAction?: boolean;
  onQuickAssign?: (id: string) => void;
}

export default function ComplaintCard({
  complaint,
  onViewDetails,
  showAssignAction = false,
  onQuickAssign,
}: ComplaintCardProps) {
  
  const getSeverityBadge = (level: string) => {
    switch (level) {
      case 'Critical':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-red-50 text-red-600 dark:bg-red-950/35 dark:text-red-400 border border-red-200 dark:border-red-900/40">
            <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse"></span>
            Critical Hazard
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center gap-1 py-0.5 px-2 rounded-full text-[10px] font-bold bg-orange-50 text-orange-600 dark:bg-orange-950/20 dark:text-orange-400 border border-orange-200 dark:border-orange-900/30">
            High Severity
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center gap-1 py-0.5 px-2 rounded-full text-[10px] font-bold bg-amber-50 text-amber-600 dark:bg-amber-950/20 dark:text-amber-400 border border-amber-200 dark:border-amber-900/20">
            Medium Severity
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 py-0.5 px-2 rounded-full text-[10px] font-bold bg-slate-50 text-slate-500 dark:bg-slate-800/60 dark:text-slate-400 border border-slate-200 dark:border-slate-800">
            Low Severity
          </span>
        );
    }
  };

  const getStatusBadge = (status: string) => {
    let style = 'bg-slate-100 text-slate-700 border-slate-200';
    if (status === 'Submitted') style = 'bg-blue-50 text-blue-600 border-blue-100 dark:bg-blue-950/15 dark:text-blue-400 dark:border-blue-900/30';
    if (status === 'Acknowledged') style = 'bg-amber-50 text-amber-600 border-amber-100 dark:bg-amber-950/15 dark:text-amber-400 dark:border-amber-900/30';
    if (status === 'Assigned') style = 'bg-indigo-50 text-indigo-600 border-indigo-100 dark:bg-indigo-950/15 dark:text-indigo-400 dark:border-indigo-900/30';
    if (status === 'In Progress') style = 'bg-yellow-50 text-yellow-600 border-yellow-100 dark:bg-yellow-950/15 dark:text-yellow-400 dark:border-yellow-900/30';
    if (status === 'Resolved') style = 'bg-emerald-50 text-emerald-600 border-emerald-100 dark:bg-emerald-950/15 dark:text-emerald-400 dark:border-emerald-900/30';
    if (status === 'Closed') style = 'bg-teal-50 text-teal-600 border-teal-100 dark:bg-teal-950/15 dark:text-teal-400 dark:border-teal-900/30';

    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${style}`}>
        {status}
      </span>
    );
  };

  const isCritical = complaint.severity === 'Critical';

  return (
    <div
      onClick={() => onViewDetails(complaint.id)}
      className={`group relative rounded-2xl border transition-all duration-300 cursor-pointer overflow-hidden p-4 sm:p-5 flex flex-col justify-between ${
        isCritical
          ? 'border-red-200 dark:border-red-950 bg-red-50/5 hover:bg-red-50/10 hover:shadow-lg hover:shadow-red-500/5 pulse-hazard dark:bg-slate-900/40'
          : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-md'
      }`}
    >
      <div className="space-y-3">
        {/* Ticket Header */}
        <div className="flex items-start justify-between gap-2">
          <div className="space-y-0.5">
            <span className="font-mono text-[10px] font-bold text-slate-400 dark:text-slate-500">
              {complaint.ticketNumber}
            </span>
            <h3 className="text-sm sm:text-base font-bold text-slate-800 dark:text-white group-hover:text-saffron transition-colors leading-tight">
              {complaint.category}
            </h3>
          </div>
          <div className="flex flex-col items-end gap-1.5 shrink-0">
            {getStatusBadge(complaint.status)}
            {getSeverityBadge(complaint.severity)}
          </div>
        </div>

        {/* Details text */}
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-3">
          {complaint.description}
        </p>

        {/* Location & Division */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 dark:text-slate-500">
          <div className="flex items-center gap-1 max-w-[240px] truncate">
            <MapPin className="h-3.5 w-3.5 text-saffron shrink-0" />
            <span>{complaint.location.district || 'Grid Location'}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="h-3.5 w-3.5 shrink-0" />
            <span>
              {new Date(complaint.createdAt).toLocaleDateString('en-IN', {
                day: '2-digit',
                month: 'short',
              })}
            </span>
          </div>
        </div>
      </div>

      {/* Footer Details */}
      <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center gap-2">
          {complaint.imageUrl && (
            <span className="inline-flex items-center gap-1 bg-saffron/10 text-saffron text-[9px] font-bold px-1.5 py-0.5 rounded uppercase font-mono border border-saffron/20">
              Vision Link
            </span>
          )}
          {complaint.voiceUrl && (
            <span className="inline-flex items-center gap-1 bg-indigo-50 dark:bg-indigo-950/20 text-indigo-500 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase font-mono border border-indigo-200/40 dark:border-indigo-900/30">
              Audio STT
            </span>
          )}
          {complaint.engineerName ? (
            <div className="flex items-center gap-1 text-[10px] font-semibold text-slate-500 dark:text-slate-400">
              <Shield className="h-3.5 w-3.5 text-govblue shrink-0" />
              <span className="truncate max-w-[80px]">{complaint.engineerName}</span>
            </div>
          ) : (
            <span className="text-[10px] text-amber-500 font-bold uppercase tracking-wider font-mono">
              Unassigned
            </span>
          )}
        </div>

        <div className="flex items-center gap-1 text-xs font-bold text-slate-600 dark:text-slate-300 group-hover:text-saffron transition-colors">
          <span>Track Ticket</span>
          <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );
}
