import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, RefreshCw, Send, CheckCheck, Clock, ShieldCheck } from 'lucide-react';
import { SupportedLanguage } from '../lib/translations.js';

interface WhatsAppLog {
  id: string;
  phone: string;
  message: string;
  ticketNumber: string;
  timestamp: string;
}

interface WhatsAppLogsProps {
  lang: SupportedLanguage;
}

export default function WhatsAppLogs({ lang }: WhatsAppLogsProps) {
  const [logs, setLogs] = useState<WhatsAppLog[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/whatsapp/logs');
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
    const interval = setInterval(fetchLogs, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 shadow-sm" id="seca-whatsapp-logs">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
            <MessageCircle className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider">
              WhatsApp Alert Gateway Log
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Live status: <span className="text-emerald-500 font-bold">● OPERATIONAL</span>
            </p>
          </div>
        </div>
        <button
          onClick={fetchLogs}
          disabled={loading}
          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-all active:scale-95 disabled:opacity-50"
          title="Refresh Logs"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        This gateway monitors our simulated central control room dispatch alerts. Whenever a consumer files a ticket or a utility officer updates a ticket status, an active WhatsApp payload is queued and fired.
      </p>

      <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
        <AnimatePresence initial={false}>
          {logs.length === 0 ? (
            <div className="text-center py-8 border-2 border-dashed border-slate-150 dark:border-slate-800 rounded-xl">
              <Clock className="h-8 w-8 text-slate-300 dark:text-slate-700 mx-auto mb-1.5" />
              <p className="text-xs text-slate-400 font-mono uppercase">
                No alerts logged yet
              </p>
              <p className="text-[10px] text-slate-400">
                Submit a complaint or update its status to watch this queue fire!
              </p>
            </div>
          ) : (
            logs.map((log) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="p-3 rounded-xl bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/20 space-y-1.5 shadow-2xs relative overflow-hidden"
              >
                {/* Visual whatsapp double tick */}
                <div className="absolute top-2 right-3 flex items-center gap-1">
                  <CheckCheck className="h-4 w-4 text-emerald-500" />
                  <span className="text-[9px] font-mono text-emerald-600 dark:text-emerald-400">DELIVERED</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 font-mono">
                    To: <strong className="text-slate-800 dark:text-slate-100">{log.phone}</strong>
                  </span>
                  <span className="h-1 w-1 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="text-[9px] text-slate-400 font-mono">
                    Ticket: <strong className="text-saffron">{log.ticketNumber}</strong>
                  </span>
                </div>

                <p className="text-xs text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-950 p-2 rounded-lg border border-slate-100 dark:border-slate-900 leading-relaxed font-sans">
                  {log.message}
                </p>

                <div className="flex items-center justify-between text-[9px] font-mono text-slate-400">
                  <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck className="h-3 w-3" /> Secure Gateway Hook
                  </span>
                  <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
