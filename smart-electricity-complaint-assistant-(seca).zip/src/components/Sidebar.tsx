import { User } from '../types';
import { LayoutDashboard, FilePlus2, History, BarChart3, UserCog, ShieldAlert, BookOpen, Settings } from 'lucide-react';

interface SidebarProps {
  user: User | null;
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export default function Sidebar({ user, activeTab, onSelectTab }: SidebarProps) {
  if (!user) return null;

  const links = [
    // Consumer Links
    {
      id: 'dashboard',
      label: 'My Dashboard',
      roles: ['consumer'],
      icon: LayoutDashboard,
    },
    {
      id: 'create-complaint',
      label: 'File Complaint',
      roles: ['consumer'],
      icon: FilePlus2,
    },
    {
      id: 'history',
      label: 'Complaint History',
      roles: ['consumer'],
      icon: History,
    },

    // Engineer Links
    {
      id: 'engineer-dashboard',
      label: 'Assigned Board',
      roles: ['engineer'],
      icon: LayoutDashboard,
    },

    // Admin Links
    {
      id: 'admin-dashboard',
      label: 'Admin Panel',
      roles: ['admin'],
      icon: ShieldAlert,
    },

    // Shared Admin/Engineer Links
    {
      id: 'analytics',
      label: 'Analytics Board',
      roles: ['admin', 'engineer'],
      icon: BarChart3,
    },

    // Global User Links
    {
      id: 'profile',
      label: 'My Account',
      roles: ['consumer', 'engineer', 'admin'],
      icon: UserCog,
    },
  ];

  const allowedLinks = links.filter((link) => link.roles.includes(user.role));

  return (
    <aside className="w-full md:w-64 shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 md:min-h-[calc(100vh-4rem)] p-4 space-y-6 transition-colors duration-200">
      <div className="space-y-1">
        <span className="px-3 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
          Main Console
        </span>
        <nav className="space-y-1">
          {allowedLinks.map((link) => {
            const Icon = link.icon;
            const isActive = activeTab === link.id;

            return (
              <button
                key={link.id}
                onClick={() => onSelectTab(link.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group relative ${
                  isActive
                    ? 'bg-saffron/10 text-saffron dark:bg-saffron/15 dark:text-saffron font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800/60'
                }`}
              >
                {/* Accent line on active */}
                {isActive && (
                  <span className="absolute left-0 top-2.5 bottom-2.5 w-1 rounded-r-md bg-saffron"></span>
                )}
                
                <Icon className={`h-5 w-5 shrink-0 transition-colors ${
                  isActive ? 'text-saffron' : 'text-slate-400 group-hover:text-slate-500 dark:text-slate-500'
                }`} />
                <span>{link.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
        <div className="rounded-xl bg-linear-to-tr from-slate-50 to-slate-100/60 dark:from-slate-800/40 dark:to-slate-900/40 p-3.5 border border-slate-100 dark:border-slate-800/60">
          <div className="flex gap-2 items-center text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
            <BookOpen className="h-4 w-4 text-govblue dark:text-saffron" />
            <span>Emergency Helpline</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal mb-2">
            For critical electrical emergencies, sparks, or wire hazards.
          </p>
          <a
            href="tel:1912"
            className="block text-center rounded-lg bg-saffron text-white py-1.5 text-xs font-bold tracking-wider hover:bg-opacity-90 active:scale-[0.98] transition-all shadow-sm"
          >
            CALL 1912 (FREE)
          </a>
        </div>
      </div>
    </aside>
  );
}
