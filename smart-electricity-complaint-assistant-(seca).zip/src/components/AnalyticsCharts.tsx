import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { AnalyticsSummary } from '../types';

interface ChartsProps {
  analytics: AnalyticsSummary | null;
  loading?: boolean;
}

const COLORS = ['#ff9933', '#138808', '#000080', '#eab308', '#ef4444', '#a855f7', '#6366f1', '#14b8a6'];

export default function AnalyticsCharts({ analytics, loading }: ChartsProps) {
  if (loading || !analytics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-72 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 animate-pulse flex flex-col justify-between">
            <div className="h-4 w-1/3 bg-slate-200 dark:bg-slate-800 rounded"></div>
            <div className="h-44 w-full bg-slate-100 dark:bg-slate-800/60 rounded"></div>
            <div className="h-4 w-2/3 bg-slate-200 dark:bg-slate-800 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  // Map category object distribution to Recharts list
  const categoryData = Object.entries(analytics.categoryDistribution).map(([name, value]) => ({
    name,
    value,
  }));

  // Map severity object distribution
  const severityData = Object.entries(analytics.severityDistribution).map(([name, value]) => ({
    name,
    value,
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Chart 1: Daily Trends */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div>
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Daily Activity Log
          </h4>
          <p className="text-sm font-semibold text-slate-800 dark:text-white">
            Submitted vs Resolved Tickets
          </p>
        </div>
        <div className="h-60 w-full text-xs">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={analytics.dailyTrends} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="colorSubmitted" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff9933" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#ff9933" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#138808" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#138808" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" className="dark:stroke-slate-800" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" allowDecimals={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '12px',
                  color: '#fff',
                }}
              />
              <Area type="monotone" dataKey="submitted" stroke="#ff9933" strokeWidth={2.5} fillOpacity={1} fill="url(#colorSubmitted)" name="Submitted" />
              <Area type="monotone" dataKey="resolved" stroke="#138808" strokeWidth={2.5} fillOpacity={1} fill="url(#colorResolved)" name="Resolved" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 2: Resolution Time speed */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div>
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Efficiency KPI Tracker
          </h4>
          <p className="text-sm font-semibold text-slate-800 dark:text-white">
            Average Resolution Time (Minutes)
          </p>
        </div>
        <div className="h-60 w-full text-xs">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={analytics.resolutionTimeTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" className="dark:stroke-slate-800" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '12px',
                  color: '#fff',
                }}
                formatter={(val) => [`${val} mins`, 'Avg Resolution Time']}
              />
              <Bar dataKey="avgTimeMinutes" fill="#000080" radius={[4, 4, 0, 0]} maxBarSize={45}>
                {analytics.resolutionTimeTrend.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 4 ? '#ff9933' : '#000080'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 3: Category Load Distribution */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div>
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Sector analysis
          </h4>
          <p className="text-sm font-semibold text-slate-800 dark:text-white">
            Load Distribution by Category
          </p>
        </div>
        <div className="h-60 w-full text-xs flex items-center justify-center">
          {categoryData.length === 0 ? (
            <p className="text-slate-400">No category load logged.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '12px',
                    color: '#fff',
                  }}
                />
                <Legend layout="horizontal" verticalAlign="bottom" align="center" iconSize={10} iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Chart 4: Severity Breakdown */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div>
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Threat & Hazard Index
          </h4>
          <p className="text-sm font-semibold text-slate-800 dark:text-white">
            Complaint Volume by Severity
          </p>
        </div>
        <div className="h-60 w-full text-xs flex items-center justify-center">
          {severityData.length === 0 ? (
            <p className="text-slate-400">No threat indexes logged.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  dataKey="value"
                >
                  {severityData.map((entry, index) => {
                    let col = '#94a3b8'; // low
                    if (entry.name === 'Critical') col = '#ef4444'; // critical red
                    if (entry.name === 'High') col = '#f97316'; // orange
                    if (entry.name === 'Medium') col = '#eab308'; // yellow
                    return <Cell key={`cell-${index}`} fill={col} />;
                  })}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '12px',
                    color: '#fff',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
