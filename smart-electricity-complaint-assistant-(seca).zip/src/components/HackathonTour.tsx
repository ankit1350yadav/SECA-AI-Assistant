import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Sparkles, AlertTriangle, Check, ArrowRight, UserCheck, ShieldAlert, Award, Globe, MessageCircle } from 'lucide-react';
import { SupportedLanguage } from '../lib/translations.js';

interface TourStep {
  title: string;
  description: string;
  role: 'guest' | 'consumer' | 'engineer' | 'admin';
  actionLabel: string;
  targetId?: string;
  highlights: string[];
}

interface HackathonTourProps {
  onTriggerAutopilot: (stepIndex: number) => void;
  lang: SupportedLanguage;
  setLang: (l: SupportedLanguage) => void;
}

export default function HackathonTour({ onTriggerAutopilot, lang, setLang }: HackathonTourProps) {
  const [isActive, setIsActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const steps: TourStep[] = [
    {
      title: "Welcome to SECA! ⚡",
      description: "Smart Electricity Complaint Assistant is designed for rural & urban India to file complaints easily, with or without internet. Let's start the 3-minute tour!",
      role: "guest",
      actionLabel: "Step 1: Go to Login & Portal",
      highlights: [
        "10+ Indian Languages (Hindi, Tamil, Telugu...)",
        "PWA Offline Form Sync",
        "Floating AI Gemini Chatbot with Form Autofill"
      ]
    },
    {
      title: "Interactive Role: Consumer (Rajesh) 👤",
      description: "We will auto-login as consumer Rajesh Kumar. You will see how simple it is to file a complaint, capture GPS location, record voice descriptions, and run real-time AI pre-diagnostics.",
      role: "consumer",
      actionLabel: "Autopilot: Login & Load Consumer Dashboard",
      highlights: [
        "One-click multi-lingual selector",
        "Voice Recorder (Speak in Hindi/English)",
        "AI pre-diagnostics model feedback"
      ]
    },
    {
      title: "Speech & Visual AI ingestion 🎙️",
      description: "See the power of Gemini AI. We will auto-prefill a ticket for 'Burnt Meter' or 'Sparks on Transformer' using natural language and trigger instant safety instructions.",
      role: "consumer",
      actionLabel: "Autopilot: Autofill Outage Complaint",
      highlights: [
        "Speech transcription & automatic classification",
        "Instant Indian safety advice",
        "WhatsApp alert dispatched instantly on creation"
      ]
    },
    {
      title: "Real-time Dispatch & Central Map 🗺️",
      description: "Now we will switch roles to Er. Sanjay Patil (Executive Admin). See the live West Delhi grid dashboard, lineman work queue, and central GIS Radar cluster.",
      role: "admin",
      actionLabel: "Autopilot: Switch to Admin Dashboard",
      highlights: [
        "Active GIS radar pins clustering West Delhi",
        "Real-time technician task queues",
        "WhatsApp Notification Dispatch logs Console"
      ]
    },
    {
      title: "PWA Offline Mode Simulation 📱",
      description: "SECA works 100% offline. Turn on offline simulation, submit tickets, and see them queued locally. They will synchronize automatically when internet is back!",
      role: "admin",
      actionLabel: "Finish Tour & Test Manually!",
      highlights: [
        "Service worker offline file caching",
        "Local queueing with zero data loss",
        "Automatic background synchronization"
      ]
    }
  ];

  const handleNextStep = () => {
    onTriggerAutopilot(currentStep);
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      setIsActive(false);
      setCurrentStep(0);
    }
  };

  const handleStopTour = () => {
    setIsActive(false);
    setCurrentStep(0);
  };

  return (
    <div className="relative">
      {/* Mini tour bar */}
      {!isActive ? (
        <div className="bg-linear-to-r from-govblue via-slate-900 to-saffron p-3.5 rounded-2xl border border-saffron/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-2">
            <Award className="h-5 w-5 text-saffron animate-bounce" />
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-display">
                Hackathon Judge Arena
              </h4>
              <p className="text-[11px] text-slate-300">
                Are you evaluating? Launch our 3-minute interactive autopilot tour!
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setIsActive(true);
              setCurrentStep(0);
            }}
            className="rounded-xl bg-saffron text-slate-950 px-4 py-2 text-[11px] font-extrabold flex items-center gap-1.5 shadow-sm active:scale-95 hover:bg-opacity-90 transition-all uppercase"
          >
            <Play className="h-3.5 w-3.5 fill-slate-950" />
            Start Interactive Tour
          </button>
        </div>
      ) : (
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-900 border-2 border-saffron/40 p-4 rounded-2xl shadow-2xl text-white space-y-4 relative overflow-hidden"
          >
            {/* Background glowing effects */}
            <div className="absolute top-0 right-0 h-24 w-24 bg-saffron/10 rounded-full blur-xl" />
            <div className="absolute -bottom-6 -left-6 h-20 w-20 bg-govblue/20 rounded-full blur-xl" />

            {/* Header info */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1.5 text-saffron">
                <Sparkles className="h-4.5 w-4.5 text-saffron" />
                <span className="text-xs font-extrabold uppercase tracking-widest font-mono">
                  SECA Autopilot Tour — Step {currentStep + 1} of {steps.length}
                </span>
              </div>
              <button
                onClick={handleStopTour}
                className="text-[10px] text-slate-400 hover:text-white border border-slate-800 px-2 py-1 rounded hover:bg-slate-800 transition-all font-mono"
              >
                CLOSE
              </button>
            </div>

            {/* Body */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-8 space-y-2">
                <h3 className="text-base font-extrabold text-white">{steps[currentStep].title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {steps[currentStep].description}
                </p>
              </div>

              {/* Highlights badge column */}
              <div className="md:col-span-4 bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-[9px] font-bold text-saffron uppercase tracking-wider font-mono block">
                  Tech Highlights:
                </span>
                <div className="space-y-1">
                  {steps[currentStep].highlights.map((h, idx) => (
                    <div key={idx} className="flex items-start gap-1 text-[10px] text-slate-300">
                      <Check className="h-3.5 w-3.5 text-ashgreen shrink-0 mt-0.5" />
                      <span className="leading-snug">{h}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-800">
              <span className="text-[10px] text-slate-400 font-mono">
                💡 Clicking the button below automatically executes navigation & data pre-filling.
              </span>
              <button
                onClick={handleNextStep}
                className="w-full sm:w-auto rounded-xl bg-linear-to-r from-saffron to-amber-500 text-slate-950 font-extrabold text-xs px-5 py-3 shadow-md hover:opacity-95 active:scale-[0.98] flex items-center justify-center gap-1.5 transition-all uppercase"
              >
                <span>{steps[currentStep].actionLabel}</span>
                <ArrowRight className="h-4 w-4 text-slate-950" />
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}
