import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register PWA service worker for offline support
if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('SECA PWA Service Worker registered:', reg.scope))
      .catch(err => console.error('PWA registration failed:', err));
  });
} else if ('serviceWorker' in navigator) {
  // Also register in dev for easy local testing
  navigator.serviceWorker.register('/sw.js')
    .then(reg => console.log('SECA Dev Service Worker registered:', reg.scope))
    .catch(err => console.error('Dev PWA registration failed:', err));
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
