import React, { useState, useEffect, FormEvent } from 'react';
import Navbar from './components/Navbar.js';
import Sidebar from './components/Sidebar.js';
import ComplaintCard from './components/ComplaintCard.js';
import ComplaintTimeline from './components/ComplaintTimeline.js';
import VoiceRecorder from './components/VoiceRecorder.js';
import ImageViewer from './components/ImageViewer.js';
import LocationPicker from './components/LocationPicker.js';
import AnalyticsCharts from './components/AnalyticsCharts.js';
import { User, Complaint, AppNotification, AnalyticsSummary, LocationData, AIAnalysisResult } from './types.js';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText, Plus, CheckCircle, Clock, ShieldAlert,
  AlertTriangle, Phone, Shield, Send, ArrowLeft, Search,
  Filter, CheckSquare, Sparkles, Building, UserCheck, HelpCircle, Heart, Check, Trash,
  Globe, Wifi, WifiOff, MessageSquare
} from 'lucide-react';
import { SupportedLanguage, LANGUAGES, translations } from './lib/translations.js';
import AIChatbot from './components/AIChatbot.js';
import HackathonTour from './components/HackathonTour.js';
import WhatsAppLogs from './components/WhatsAppLogs.js';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('landing');
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | null>(null);
  const [selectedComplaint, setSelectedComplaint] = useState<(Complaint & { timeline?: any[] }) | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [engineers, setEngineers] = useState<any[]>([]);
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // Multilingual & Translation states
  const [lang, setLang] = useState<SupportedLanguage>('en');
  const t = (key: string): string => {
    return translations[lang]?.[key] || translations['en']?.[key] || key;
  };

  // PWA Offline state tracking
  const [isOnline, setIsOnline] = useState<boolean>(window.navigator.onLine);
  const [offlineSyncBanner, setOfflineSyncBanner] = useState<string | null>(null);

  // Authentication states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('password');
  const [authError, setAuthError] = useState<string | null>(null);
  
  // Registration states
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regConsumerId, setRegConsumerId] = useState('');
  const [regState, setRegState] = useState('Delhi');
  const [regDistrict, setRegDistrict] = useState('West Delhi');
  const [regError, setRegError] = useState<string | null>(null);

  // Complaint Submission state
  const [formCategory, setFormCategory] = useState<string>('Power Outage');
  const [formDescription, setFormDescription] = useState<string>('');
  const [formLocation, setFormLocation] = useState<LocationData>({
    address: 'Dwarka, New Delhi',
    state: 'Delhi',
    district: 'West Delhi',
    latitude: 28.6139,
    longitude: 77.2090
  });
  const [formImageUrl, setFormImageUrl] = useState<string>('');
  const [formVoiceUrl, setFormVoiceUrl] = useState<string>('');
  
  // AI pre-diagnostics states
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [fileSubmitting, setFileSubmitting] = useState(false);
  const [fileSuccess, setFileSuccess] = useState(false);

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('');

  // Admin/Engineer Actions
  const [assignEngineerId, setAssignEngineerId] = useState('');
  const [statusUpdateVal, setStatusUpdateVal] = useState('');
  const [actionComments, setActionComments] = useState('');
  const [isUpdatingComplaint, setIsUpdatingComplaint] = useState(false);

  // Initial local theme loading
  useEffect(() => {
    const savedTheme = localStorage.getItem('seca_theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setDarkMode(false);
      document.documentElement.classList.remove('dark');
    }

    // Try auto logging-in from local session
    const savedToken = localStorage.getItem('seca_token');
    const savedUser = localStorage.getItem('seca_user');
    if (savedToken && savedUser) {
      setToken(savedToken);
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      // Auto routing based on role
      if (parsedUser.role === 'consumer') {
        setActiveTab('dashboard');
      } else if (parsedUser.role === 'engineer') {
        setActiveTab('engineer-dashboard');
      } else if (parsedUser.role === 'admin') {
        setActiveTab('admin-dashboard');
      }
    }
  }, []);

  // Listen to Online/Offline transitions and sync queued offline complaints
  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      
      // Attempt to sync offline complaints
      const queuedStr = localStorage.getItem('seca_offline_complaints');
      if (queuedStr) {
        try {
          const queuedList: any[] = JSON.parse(queuedStr);
          if (queuedList.length > 0) {
            setOfflineSyncBanner("Syncing offline complaints back to power grid...");
            for (const payload of queuedList) {
              await fetch('/api/complaints', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(payload)
              });
            }
            localStorage.removeItem('seca_offline_complaints');
            setOfflineSyncBanner("🎉 Connection restored! Offline complaints successfully synchronized.");
            fetchComplaints();
            setTimeout(() => setOfflineSyncBanner(null), 5000);
          }
        } catch (err) {
          console.error("Failed to sync offline complaints:", err);
        }
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setOfflineSyncBanner("Offline Mode Active. Issues reported will be saved locally.");
      setTimeout(() => setOfflineSyncBanner(null), 5000);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [token]);

  const toggleDarkMode = () => {
    const nextTheme = !darkMode;
    setDarkMode(nextTheme);
    if (nextTheme) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('seca_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('seca_theme', 'light');
    }
  };

  // Synchronize dynamic data when logged in
  useEffect(() => {
    if (!token) return;

    fetchComplaints();
    fetchNotifications();

    if (user?.role === 'admin' || user?.role === 'engineer') {
      fetchAnalytics();
      fetchEngineers();
    }
  }, [token, activeTab]);

  const fetchComplaints = async () => {
    try {
      const url = new URL('/api/complaints', window.location.origin);
      if (searchQuery) url.searchParams.append('search', searchQuery);
      if (filterCategory) url.searchParams.append('category', filterCategory);
      if (filterStatus) url.searchParams.append('status', filterStatus);
      if (filterSeverity) url.searchParams.append('severity', filterSeverity);

      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setComplaints(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch('/api/analytics', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchEngineers = async () => {
    try {
      const res = await fetch('/api/engineers', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setEngineers(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleMarkNotificationsAsRead = async () => {
    try {
      const res = await fetch('/api/notifications/read', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogin = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    setAuthError(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });

      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error);
        return;
      }

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem('seca_token', data.token);
      localStorage.setItem('seca_user', JSON.stringify(data.user));

      if (data.user.role === 'consumer') {
        setActiveTab('dashboard');
      } else if (data.user.role === 'engineer') {
        setActiveTab('engineer-dashboard');
      } else if (data.user.role === 'admin') {
        setActiveTab('admin-dashboard');
      }
    } catch (err) {
      setAuthError('Connection failure to authentication server.');
    }
  };

  const handleDemoLogin = (email: string) => {
    setLoginEmail(email);
    setLoginPassword('password');
    // We delay slightly so state is updated before submit
    setTimeout(() => {
      const form = document.getElementById('login-form') as HTMLFormElement;
      if (form) {
        form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
      } else {
        // Fallback programmatic login
        setToken(`token-${email.includes('consumer') ? 'usr-consumer' : email.includes('engineer') ? 'usr-engineer' : 'usr-admin'}`);
        const userObj = email.includes('consumer')
          ? { id: 'usr-consumer', name: 'Rajesh Kumar', email, phone: '+91 98765 43210', role: 'consumer' as const, consumerId: 'CON-DL-4028492' }
          : email.includes('engineer')
          ? { id: 'usr-engineer', name: 'Amit Sharma', email, phone: '+91 87654 32109', role: 'engineer' as const }
          : { id: 'usr-admin', name: 'Er. Sanjay Patil', email, phone: '+91 76543 21098', role: 'admin' as const };
        setUser(userObj);
        localStorage.setItem('seca_token', `token-${userObj.id}`);
        localStorage.setItem('seca_user', JSON.stringify(userObj));
        setActiveTab(userObj.role === 'consumer' ? 'dashboard' : userObj.role === 'engineer' ? 'engineer-dashboard' : 'admin-dashboard');
      }
    }, 100);
  };

  const handleRegister = async (e: FormEvent) => {
    e.preventDefault();
    setRegError(null);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          email: regEmail,
          phone: regPhone,
          consumerId: regConsumerId,
          state: regState,
          district: regDistrict,
          role: 'consumer'
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setRegError(data.error);
        return;
      }

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem('seca_token', data.token);
      localStorage.setItem('seca_user', JSON.stringify(data.user));
      setActiveTab('dashboard');
    } catch (err) {
      setRegError('Connection failure to registration server.');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setToken('');
    localStorage.removeItem('seca_token');
    localStorage.removeItem('seca_user');
    setActiveTab('landing');
  };

  // AI Diagnostic Pre-Analysis
  const handleAIAnalyze = async () => {
    if (!formDescription && !formImageUrl && !formVoiceUrl) {
      alert('Please write details, record a voice clip, or upload an image before requesting AI analysis.');
      return;
    }

    setAnalyzing(true);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          text: formDescription,
          image: formImageUrl,
          latitude: formLocation.latitude,
          longitude: formLocation.longitude
        }),
      });

      if (!res.ok) throw new Error('AI Engine failed to compute.');
      const result = await res.json();
      setAiAnalysis(result);
      
      // Auto propagate AI findings into forms for validation/correction
      setFormCategory(result.category);
    } catch (err) {
      alert('AI Diagnosis Pipeline is currently busy. Utilizing local standard heuristics.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCreateComplaintSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFileSubmitting(true);

    const payload = {
      category: formCategory,
      description: formDescription,
      location: formLocation,
      imageUrl: formImageUrl,
      voiceUrl: formVoiceUrl,
      severity: aiAnalysis?.severity || 'Medium',
      priority: aiAnalysis?.priority || 'Medium',
      department: aiAnalysis?.department || 'Overhead Lines & Poles',
      aiAnalysis: aiAnalysis || undefined
    };

    // PWA Offline check intercept
    if (!navigator.onLine || !isOnline) {
      try {
        const existingQueue = localStorage.getItem('seca_offline_complaints');
        const queueList = existingQueue ? JSON.parse(existingQueue) : [];
        queueList.push(payload);
        localStorage.setItem('seca_offline_complaints', JSON.stringify(queueList));

        // Create virtual offline complaint to render immediately
        const mockTicketNumber = `SECA-2026-OFF-${Math.floor(1000 + Math.random() * 9000)}`;
        const mockOfflineComplaint: Complaint = {
          id: `offline-${Date.now()}`,
          ticketNumber: mockTicketNumber,
          consumerId: user?.consumerId || 'CON-GUEST',
          consumerName: user?.name || 'Local User',
          consumerPhone: user?.phone || '+91 99999 88888',
          category: formCategory,
          description: formDescription + ' [QUEUED OFFLINE]',
          location: formLocation,
          imageUrl: formImageUrl,
          voiceUrl: formVoiceUrl,
          status: 'Submitted',
          severity: aiAnalysis?.severity || 'Medium',
          priority: aiAnalysis?.priority || 'Medium',
          department: aiAnalysis?.department || 'General Maintenance',
          aiAnalysis: aiAnalysis || undefined,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        setComplaints(prev => [mockOfflineComplaint, ...prev]);
        setFileSuccess(true);
        setFormDescription('');
        setFormImageUrl('');
        setFormVoiceUrl('');
        setAiAnalysis(null);

        setOfflineSyncBanner("Complaint saved locally! We will auto-sync when internet is restored.");
        setTimeout(() => {
          setOfflineSyncBanner(null);
          setFileSuccess(false);
          setActiveTab('history');
        }, 2000);
      } catch (err) {
        console.error("Local queueing failed", err);
      } finally {
        setFileSubmitting(false);
      }
      return;
    }

    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setFileSuccess(true);
        // Clear forms
        setFormDescription('');
        setFormImageUrl('');
        setFormVoiceUrl('');
        setAiAnalysis(null);
        
        setTimeout(() => {
          setFileSuccess(false);
          setActiveTab('history');
        }, 1500);
      }
    } catch (e) {
      alert('Failed to register complaint.');
    } finally {
      setFileSubmitting(false);
    }
  };

  const handleAutoFillDraft = (category: string, description: string) => {
    if (!token) {
      handleDemoLogin('consumer@seca.in');
      setTimeout(() => {
        setFormCategory(category);
        setFormDescription(description);
        setActiveTab('new-complaint');
      }, 800);
    } else {
      setFormCategory(category);
      setFormDescription(description);
      setActiveTab('new-complaint');
    }
  };

  const handleTriggerAutopilot = (stepIndex: number) => {
    switch (stepIndex) {
      case 0:
        // Welcome -> Login Page
        setActiveTab('login');
        break;
      case 1:
        // Login & Load Consumer Dashboard
        handleDemoLogin('consumer@seca.in');
        break;
      case 2:
        // Autofill Outage Complaint
        setFormCategory('Transformer Damage');
        setFormDescription('High voltage power surge caused our street transformer to catch fire with heavy sparks and smoke near Block D gate 3.');
        setFormLocation({
          latitude: 28.6215,
          longitude: 77.1124,
          address: 'Block D Market, Janakpuri, West Delhi, New Delhi 110058',
          state: 'Delhi',
          district: 'West Delhi'
        });
        setLang('hi'); // Switch to Hindi to show language support!
        setAiAnalysis({
          category: 'Transformer Damage',
          priority: 'Immediate',
          severity: 'Critical',
          department: 'Overhead Lines & Poles',
          summary: 'Transformer catching fire with live sparking hazards near residential gate. Severe electrocution and blackout hazard.',
          safety: [
            'Stay at least 30 meters away from the sparking transformer.',
            'Do not use any water to extinguish the electrical fire.',
            'Warn children and neighbors to stay indoors.'
          ],
          confidence: 98,
          duplicateDetected: false,
          engineerSummary: 'Dispatch emergency overhead crew immediately. Isolate high-tension feeder line at local substation.'
        });
        setActiveTab('new-complaint');
        break;
      case 3:
        // Switch to Admin Dashboard
        handleDemoLogin('admin@seca.in');
        setLang('en'); // Switch back to English
        break;
      case 4:
        // Finish Tour -> Back to Landing
        setActiveTab('landing');
        alert("🎉 Autopilot Tour completed! You've seen multi-lingual support, AI speech/vision classification, live WhatsApp dispatch monitoring, and admin GIS radars. Try reporting an issue offline next!");
        break;
      default:
        break;
    }
  };

  const handleViewComplaintDetails = async (id: string) => {
    setSelectedComplaintId(id);
    setActiveTab('complaint-details');
    try {
      const res = await fetch(`/api/complaints/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedComplaint(data);
        setStatusUpdateVal(data.status);
        setAssignEngineerId(data.engineerId || '');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Admin/Engineer Status & Assignment Update
  const handleUpdateComplaintAction = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedComplaintId) return;
    setIsUpdatingComplaint(true);

    try {
      const res = await fetch(`/api/complaints/${selectedComplaintId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          status: statusUpdateVal,
          engineerId: assignEngineerId || undefined,
          comments: actionComments
        }),
      });

      if (res.ok) {
        // Refresh details
        handleViewComplaintDetails(selectedComplaintId);
        setActionComments('');
        alert('Complaint updated successfully!');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsUpdatingComplaint(false);
    }
  };

  // Admin Delete ticket
  const handleDeleteComplaint = async (id: string) => {
    if (!window.confirm('Are you absolutely sure you want to delete this ticket? This cannot be undone.')) return;
    try {
      const res = await fetch(`/api/complaints/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        alert('Ticket deleted successfully.');
        setActiveTab(user?.role === 'admin' ? 'admin-dashboard' : 'history');
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''} bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 transition-colors duration-200 flex flex-col`}>
      <Navbar
        user={user}
        notifications={notifications}
        onMarkNotificationsAsRead={handleMarkNotificationsAsRead}
        onLogout={handleLogout}
        onNavigateToProfile={() => setActiveTab('profile')}
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
        lang={lang}
        onLangChange={setLang}
        isOnline={isOnline}
      />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto">
        <Sidebar user={user} activeTab={activeTab} onSelectTab={setActiveTab} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden">
          {/* Offline Sync Banner Alerts */}
          <AnimatePresence>
            {offlineSyncBanner && (
              <motion.div
                initial={{ opacity: 0, y: -15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="mb-6 p-3.5 rounded-xl border border-saffron/30 bg-linear-to-r from-saffron/15 to-amber-500/10 text-slate-900 dark:text-white flex items-center gap-3 shadow-md"
              >
                <div className="h-2 w-2 rounded-full bg-saffron animate-pulse shrink-0" />
                <span className="text-xs font-bold leading-normal">{offlineSyncBanner}</span>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence mode="wait">
            {/* ----------------------------------------------------
                LANDING / PORTAL VIEW
                ---------------------------------------------------- */}
            {activeTab === 'landing' && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="space-y-12 py-6"
              >
                {/* Hackathon Judge Interactive Autopilot Arena */}
                <HackathonTour onTriggerAutopilot={handleTriggerAutopilot} lang={lang} setLang={setLang} />

                {/* Hero Headline section */}
                <div className="text-center max-w-3xl mx-auto space-y-4">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-saffron/10 text-saffron border border-saffron/20 uppercase tracking-widest font-mono">
                    🇮🇳 DIGITAL INDIA POWER UTILITY INITIATIVE
                  </span>
                  <h1 className="font-display text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
                    Smart Electricity <br />
                    <span className="bg-linear-to-r from-saffron via-govblue to-ashgreen bg-clip-text text-transparent">
                      Complaint Assistant
                    </span>
                  </h1>
                  <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
                    SECA helps Indian electricity consumers report power outages, sparking transformers, hanging wires, and billing discrepancies. Empowered by Gemini AI for rapid category classification and safety reports.
                  </p>
                  
                  <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
                    <button
                      id="btn-portal-consumer"
                      onClick={() => setActiveTab('login')}
                      className="rounded-xl bg-linear-to-tr from-saffron to-govblue text-white font-bold text-xs sm:text-sm px-6 py-3.5 shadow-md active:scale-95 transition-all"
                    >
                      FILE COMPLAINT PORTAL
                    </button>
                    <button
                      id="btn-portal-admin"
                      onClick={() => setActiveTab('login')}
                      className="rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold text-xs sm:text-sm px-6 py-3.5 border border-slate-200 dark:border-slate-700 transition-all active:scale-95"
                    >
                      OFFICER / LINEMAN LOGIN
                    </button>
                  </div>
                </div>

                {/* Grid features */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2.5">
                    <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-saffron/10 text-saffron font-bold text-lg">🎙️</div>
                    <h3 className="text-base font-bold text-slate-800 dark:text-white">Voice Complaint Ingestion</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Don't type. Just speak in Hindi or English. Our automated speech-to-text pipeline transcribes electrical hazard events with high precision.
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2.5">
                    <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-govblue/10 text-govblue dark:text-saffron font-bold text-lg">👁️</div>
                    <h3 className="text-base font-bold text-slate-800 dark:text-white">AI Vision Diagnostics</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Upload photos of damaged power cables or burnt meters. Gemini analyzes images to classify severity, prioritize dispatch, and issue emergency precautions.
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2.5">
                    <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-ashgreen/10 text-ashgreen font-bold text-lg">📍</div>
                    <h3 className="text-base font-bold text-slate-800 dark:text-white">GPS Coordinate Tagging</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Pinpoint exact locations automatically using smartphone location tags. Helps engineers isolate affected transformers or faulty segments in seconds.
                    </p>
                  </div>
                </div>

                {/* Demo Logins Box */}
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-linear-to-tr from-slate-50 to-slate-100/60 dark:from-slate-900/40 dark:to-slate-950/40 p-6 space-y-4 max-w-2xl mx-auto text-center">
                  <div>
                    <h3 className="text-sm font-bold text-saffron uppercase tracking-widest font-mono">
                      EXPRESS TESTING CONTROL
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Instantly enter different system roles in one click. No registration required!
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <button
                      onClick={() => handleDemoLogin('consumer@seca.in')}
                      className="flex flex-col items-center justify-center p-3 rounded-xl border border-blue-200 dark:border-blue-950 bg-white dark:bg-slate-900 hover:border-blue-400 transition-all text-center"
                    >
                      <span className="text-xs font-bold text-slate-800 dark:text-white">Rajesh Kumar</span>
                      <span className="text-[10px] text-blue-500 font-bold uppercase">Consumer View</span>
                    </button>
                    <button
                      onClick={() => handleDemoLogin('engineer@seca.in')}
                      className="flex flex-col items-center justify-center p-3 rounded-xl border border-indigo-200 dark:border-indigo-950 bg-white dark:bg-slate-900 hover:border-indigo-400 transition-all text-center"
                    >
                      <span className="text-xs font-bold text-slate-800 dark:text-white">Amit Sharma</span>
                      <span className="text-[10px] text-indigo-500 font-bold uppercase">Lineman / Field View</span>
                    </button>
                    <button
                      onClick={() => handleDemoLogin('admin@seca.in')}
                      className="flex flex-col items-center justify-center p-3 rounded-xl border border-saffron/20 bg-white dark:bg-slate-900 hover:border-saffron/55 transition-all text-center"
                    >
                      <span className="text-xs font-bold text-slate-800 dark:text-white">Er. Sanjay Patil</span>
                      <span className="text-[10px] text-saffron font-bold uppercase">Executive Admin</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ----------------------------------------------------
                LOGIN & REGISTRATION VIEW
                ---------------------------------------------------- */}
            {activeTab === 'login' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="max-w-md mx-auto py-8 space-y-6"
              >
                <div className="text-center space-y-1">
                  <h2 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                    Access SECA Portal
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Secure complaint tracing for consumers and electrical engineers
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-5">
                  <form id="login-form" onSubmit={handleLogin} className="space-y-4">
                    {authError && (
                      <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/20 text-xs font-semibold text-red-500 border border-red-200/40">
                        {authError}
                      </div>
                    )}

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                        Registered Email Address
                      </label>
                      <input
                        type="email"
                        required
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="e.g. consumer@seca.in"
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          Password Key
                        </label>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 hover:text-saffron cursor-pointer">
                          Forgot Password?
                        </span>
                      </div>
                      <input
                        type="password"
                        required
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full rounded-xl bg-linear-to-tr from-saffron to-govblue text-white font-bold py-3 text-xs sm:text-sm active:scale-95 transition-all shadow-sm"
                    >
                      AUTHENTICATE SESSION
                    </button>
                  </form>

                  <div className="relative text-center pb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 bg-white dark:bg-slate-900 px-2 absolute -bottom-2 left-1/2 -translate-x-1/2">
                      OR REGISTER
                    </span>
                  </div>

                  {/* Register Form Shortcut toggle */}
                  <div className="pt-2 text-center">
                    <button
                      onClick={() => setActiveTab('register')}
                      className="text-xs font-bold text-saffron hover:underline"
                    >
                      Create a new Consumer Account
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'register' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="max-w-md mx-auto py-4 space-y-6"
              >
                <div className="text-center space-y-1">
                  <h2 className="font-display text-2xl font-extrabold text-slate-900 dark:text-white">
                    Consumer Registration
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Connect your electric service connection meter number instantly
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-sm space-y-4">
                  <form onSubmit={handleRegister} className="space-y-4">
                    {regError && (
                      <div className="p-3 rounded-lg bg-red-50 dark:bg-red-950/20 text-xs font-semibold text-red-500 border border-red-200/40">
                        {regError}
                      </div>
                    )}

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                        Full Name
                      </label>
                      <input
                        type="text"
                        required
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="e.g. Ramesh Patel"
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          Email
                        </label>
                        <input
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="ramesh@gmail.com"
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          Mobile (+91)
                        </label>
                        <input
                          type="text"
                          required
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="e.g. 9811022330"
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                        Service Connection Number (Meter ID)
                      </label>
                      <input
                        type="text"
                        value={regConsumerId}
                        onChange={(e) => setRegConsumerId(e.target.value)}
                        placeholder="e.g. CON-DL-4028492"
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          State
                        </label>
                        <input
                          type="text"
                          value={regState}
                          onChange={(e) => setRegState(e.target.value)}
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          District Division
                        </label>
                        <input
                          type="text"
                          value={regDistrict}
                          onChange={(e) => setRegDistrict(e.target.value)}
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:border-saffron"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full rounded-xl bg-saffron text-white font-bold py-3 text-xs sm:text-sm active:scale-95 transition-all shadow-sm"
                    >
                      REGISTER ACCOUNT
                    </button>
                  </form>

                  <div className="text-center pt-2">
                    <button
                      onClick={() => setActiveTab('login')}
                      className="text-xs font-bold text-slate-500 hover:text-saffron"
                    >
                      Already have an account? Login
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ----------------------------------------------------
                CONSUMER DASHBOARD
                ---------------------------------------------------- */}
            {activeTab === 'dashboard' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {/* Header Welcome Card */}
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
                  <div>
                    <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>Namaste, {user?.name}!</span>
                      <span className="text-base">👋</span>
                    </h2>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                      Connection No: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{user?.consumerId}</span> • Zone: {user?.district}, {user?.state}
                    </p>
                  </div>
                  <button
                    id="btn-trigger-file-complaint"
                    onClick={() => setActiveTab('create-complaint')}
                    className="flex items-center gap-1.5 rounded-xl bg-saffron text-white text-xs font-bold px-4 py-2.5 active:scale-95 transition-all"
                  >
                    <Plus className="h-4 w-4" />
                    <span>File New Complaint</span>
                  </button>
                </div>

                {/* KPI Cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex items-center gap-3">
                    <div className="h-9 w-9 flex items-center justify-center rounded-lg bg-blue-50 dark:bg-blue-950/20 text-blue-500">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase leading-none mb-1">Total</p>
                      <p className="text-lg font-bold text-slate-800 dark:text-white leading-none">
                        {complaints.length}
                      </p>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex items-center gap-3">
                    <div className="h-9 w-9 flex items-center justify-center rounded-lg bg-yellow-50 dark:bg-yellow-950/20 text-yellow-500">
                      <Clock className="h-5 w-5 animate-spin" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase leading-none mb-1">Active</p>
                      <p className="text-lg font-bold text-slate-800 dark:text-white leading-none">
                        {complaints.filter(c => c.status !== 'Resolved' && c.status !== 'Closed').length}
                      </p>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex items-center gap-3">
                    <div className="h-9 w-9 flex items-center justify-center rounded-lg bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500">
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase leading-none mb-1">Resolved</p>
                      <p className="text-lg font-bold text-slate-800 dark:text-white leading-none">
                        {complaints.filter(c => c.status === 'Resolved' || c.status === 'Closed').length}
                      </p>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex items-center gap-3">
                    <div className="h-9 w-9 flex items-center justify-center rounded-lg bg-red-50 dark:bg-red-950/20 text-red-500">
                      <AlertTriangle className="h-5 w-5 animate-bounce" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase leading-none mb-1">Critical</p>
                      <p className="text-lg font-bold text-slate-800 dark:text-white leading-none">
                        {complaints.filter(c => c.severity === 'Critical' && c.status !== 'Resolved' && c.status !== 'Closed').length}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Complaint Lists */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      Recent Complaint Filings
                    </h3>
                    <button
                      onClick={() => setActiveTab('history')}
                      className="text-xs font-semibold text-saffron hover:underline"
                    >
                      View All Logs
                    </button>
                  </div>

                  {complaints.length === 0 ? (
                    <div className="rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/40 p-8 text-center space-y-3">
                      <div className="h-10 w-10 mx-auto flex items-center justify-center rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400">
                        <FileText className="h-5 w-5" />
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">No complaints filed yet. Click "File New Complaint" to begin.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {complaints.slice(0, 4).map(c => (
                        <ComplaintCard
                          key={c.id}
                          complaint={c}
                          onViewDetails={handleViewComplaintDetails}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* ----------------------------------------------------
                FILE NEW COMPLAINT FORM
                ---------------------------------------------------- */}
            {activeTab === 'create-complaint' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div>
                    <h2 className="font-display text-xl font-extrabold text-slate-900 dark:text-white">
                      Register Electric Fault Ticket
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Provide details manually or utilize AI Voice & Image diagnostic pipeline
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className="flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-slate-700"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Back</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Left Column: Forms and text */}
                  <div className="lg:col-span-2 space-y-4">
                    <form onSubmit={handleCreateComplaintSubmit} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 shadow-xs">
                      {/* Category Selector */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          Select Fault Category
                        </label>
                        <select
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value)}
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2.5 text-xs font-medium text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden"
                        >
                          <option value="Power Outage">Power Outage</option>
                          <option value="Low Voltage">Low Voltage</option>
                          <option value="High Voltage">High Voltage</option>
                          <option value="Transformer Damage">Transformer Damage</option>
                          <option value="Burnt Meter">Burnt Meter</option>
                          <option value="Broken Pole">Broken Pole</option>
                          <option value="Hanging Wire">Hanging Wire</option>
                          <option value="Street Light Failure">Street Light Failure</option>
                          <option value="Electric Shock Hazard">Electric Shock Hazard</option>
                          <option value="Billing Issue">Billing Issue</option>
                          <option value="Meter Not Working">Meter Not Working</option>
                          <option value="Illegal Connection">Illegal Connection</option>
                        </select>
                      </div>

                      {/* Description Area */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          Detailed Description of Event
                        </label>
                        <textarea
                          required
                          value={formDescription}
                          onChange={(e) => setFormDescription(e.target.value)}
                          placeholder="Describe exactly what happened. (e.g., Sparks emitting from tree lines over DW-18 overhead cables during rain, causing transformer pop noise...)"
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2.5 text-xs text-slate-800 dark:text-slate-100 focus:border-saffron focus:outline-hidden leading-relaxed"
                          rows={4}
                        />
                      </div>

                      {/* GPS coordinates Picker */}
                      <LocationPicker
                        onLocationSelected={setFormLocation}
                        initialLocation={formLocation}
                      />

                      {/* AI Diagnostic Check trigger */}
                      <div className="flex gap-2.5 pt-2">
                        <button
                          type="button"
                          onClick={handleAIAnalyze}
                          disabled={analyzing}
                          className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-slate-950 dark:bg-saffron text-white py-3 text-xs font-bold shadow-md hover:bg-opacity-95 active:scale-[0.98] transition-all"
                        >
                          <Sparkles className="h-4 w-4 text-saffron dark:text-white" />
                          <span>{analyzing ? 'AI DEEP CLASSIFYING...' : 'RUN AI SMART PRE-DIAGNOSTICS'}</span>
                        </button>
                        
                        <button
                          type="submit"
                          disabled={fileSubmitting || fileSuccess}
                          className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-saffron dark:bg-govblue text-white py-3 text-xs font-bold shadow-md hover:bg-opacity-95 active:scale-[0.98] transition-all disabled:opacity-50"
                        >
                          <Send className="h-4 w-4" />
                          <span>{fileSubmitting ? 'INGESTING TICKET...' : fileSuccess ? 'TICKET FILED!' : 'SUBMIT RECTIFICATION TICKET'}</span>
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Right Column: Ingestors (Voice & Image) & AI Audit Report */}
                  <div className="space-y-4">
                    {/* Visual Photo attachment */}
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
                      <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                        Visual Evidence Link
                      </h4>
                      <ImageViewer onImageCaptured={setFormImageUrl} initialImage={formImageUrl} />
                    </div>

                    {/* Microphone Ingestion */}
                    <VoiceRecorder
                      onTranscriptReceived={(t) => setFormDescription(t)}
                      authToken={token}
                    />

                    {/* AI Audit Report Card */}
                    {aiAnalysis && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="rounded-2xl border border-saffron/30 bg-linear-to-tr from-saffron/5 to-white dark:to-slate-900 p-4 space-y-3.5 shadow-sm"
                      >
                        <div className="flex items-center justify-between border-b border-saffron/20 pb-1.5">
                          <div className="flex items-center gap-1.5">
                            <Sparkles className="h-4 w-4 text-saffron animate-pulse" />
                            <h4 className="text-xs font-bold text-slate-800 dark:text-white">AI Diagnostic Report</h4>
                          </div>
                          <span className="text-[10px] font-mono font-bold text-saffron">
                            Confidence: {aiAnalysis.confidence}%
                          </span>
                        </div>

                        {/* Warnings on Duplicate */}
                        {aiAnalysis.duplicateDetected && (
                          <div className="p-2 rounded-lg bg-red-50 dark:bg-red-950/20 text-[10px] font-bold text-red-600 dark:text-red-400 border border-red-200/40 flex gap-1 items-start">
                            <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5 animate-bounce" />
                            <span>
                              Grid duplicate detected! Open Ticket ({aiAnalysis.duplicateTicketNumber}) matches your category nearby. Our field engineers are already notified, but you can still submit.
                            </span>
                          </div>
                        )}

                        <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                          <div className="p-2 rounded bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                            <span className="text-slate-400">Severity:</span>
                            <p className="font-bold text-slate-700 dark:text-slate-200">{aiAnalysis.severity}</p>
                          </div>
                          <div className="p-2 rounded bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                            <span className="text-slate-400">Priority:</span>
                            <p className="font-bold text-slate-700 dark:text-slate-200">{aiAnalysis.priority}</p>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                            Auto Ingest Summary
                          </span>
                          <p className="text-xs text-slate-600 dark:text-slate-300 italic leading-relaxed">
                            "{aiAnalysis.summary}"
                          </p>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider font-mono">
                            Consumer Safety Instructions
                          </span>
                          <ul className="text-[11px] text-slate-600 dark:text-slate-400 space-y-1 pl-3.5 list-disc leading-relaxed">
                            {aiAnalysis.safety.map((s, idx) => (
                              <li key={idx}>{s}</li>
                            ))}
                          </ul>
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* ----------------------------------------------------
                COMPLAINT HISTORY / ARCHIVE
                ---------------------------------------------------- */}
            {activeTab === 'history' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-5"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div>
                    <h2 className="font-display text-xl font-extrabold text-slate-900 dark:text-white">
                      Grid Complaint History
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Track resolution audits, status timelines, and dispatch notes
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <select
                      value={filterCategory}
                      onChange={(e) => { setFilterCategory(e.target.value); setTimeout(fetchComplaints, 50); }}
                      className="rounded-lg border border-slate-200 dark:border-slate-800 px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900"
                    >
                      <option value="">All Categories</option>
                      <option value="Power Outage">Power Outage</option>
                      <option value="Hanging Wire">Hanging Wire</option>
                      <option value="Transformer Damage">Transformer Damage</option>
                      <option value="Burnt Meter">Burnt Meter</option>
                    </select>
                    <select
                      value={filterStatus}
                      onChange={(e) => { setFilterStatus(e.target.value); setTimeout(fetchComplaints, 50); }}
                      className="rounded-lg border border-slate-200 dark:border-slate-800 px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900"
                    >
                      <option value="">All Statuses</option>
                      <option value="Submitted">Submitted</option>
                      <option value="Assigned">Assigned</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Resolved">Resolved</option>
                    </select>
                  </div>
                </div>

                {complaints.length === 0 ? (
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 p-8 bg-white dark:bg-slate-900 text-center text-xs text-slate-400">
                    No tickets match selected filters.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {complaints.map(c => (
                      <ComplaintCard
                        key={c.id}
                        complaint={c}
                        onViewDetails={handleViewComplaintDetails}
                      />
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {/* ----------------------------------------------------
                ENGINEER DASHBOARD
                ---------------------------------------------------- */}
            {activeTab === 'engineer-dashboard' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs">
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                    Field Lineman Board: {user?.name}
                  </h2>
                  <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                    Role: <span className="font-bold text-saffron uppercase">Overhead Line Technician</span> • State/District: {user?.state} • Status: <span className="text-emerald-500 font-bold">On Field (Active)</span>
                  </p>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                    Assigned Field Tickets
                  </h3>

                  {complaints.length === 0 ? (
                    <div className="p-8 border rounded-2xl text-center bg-white dark:bg-slate-900 text-slate-400 text-xs">
                      No tickets assigned currently. Grab a cup of chai! ☕
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {complaints.map(c => (
                        <ComplaintCard
                          key={c.id}
                          complaint={c}
                          onViewDetails={handleViewComplaintDetails}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* ----------------------------------------------------
                ADMIN DASHBOARD
                ---------------------------------------------------- */}
            {activeTab === 'admin-dashboard' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {/* Admin Header Info */}
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xs">
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                    Corporate Executive Control Board
                  </h2>
                  <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                    Manage active lineman divisions, dispatch workflows, view real-time grid alerts, and review AI audit telemetry.
                  </p>
                </div>

                {/* KPI summaries */}
                {analytics && (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
                      <span className="text-[10px] font-bold text-slate-400 uppercase font-mono">Total Logged</span>
                      <p className="text-2xl font-bold text-slate-800 dark:text-white mt-1">{analytics.total}</p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
                      <span className="text-[10px] font-bold text-amber-500 uppercase font-mono">Pending Dispatch</span>
                      <p className="text-2xl font-bold text-amber-500 mt-1">{analytics.pending}</p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
                      <span className="text-[10px] font-bold text-emerald-500 uppercase font-mono">Resolved</span>
                      <p className="text-2xl font-bold text-emerald-500 mt-1">{analytics.resolved}</p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
                      <span className="text-[10px] font-bold text-red-500 uppercase font-mono">Critical Hazards</span>
                      <p className="text-2xl font-bold text-red-500 mt-1 animate-pulse">{analytics.critical}</p>
                    </div>
                  </div>
                )}

                {/* Admin Grid List with filtering controls */}
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-2">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                      Consolidated Ticket Master
                    </h3>
                    
                    {/* Search panel */}
                    <div className="flex items-center gap-1.5 w-full sm:w-auto">
                      <div className="relative flex-1 sm:w-64">
                        <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => { setSearchQuery(e.target.value); setTimeout(fetchComplaints, 50); }}
                          placeholder="Search address, ticket ID, consumer..."
                          className="w-full rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 pl-9 pr-3 py-1.5 text-xs focus:outline-hidden"
                        />
                      </div>
                    </div>
                  </div>

                  {complaints.length === 0 ? (
                    <p className="text-center text-xs text-slate-400 py-6">No matching complaints in grid database.</p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {complaints.map(c => (
                        <ComplaintCard
                          key={c.id}
                          complaint={c}
                          onViewDetails={handleViewComplaintDetails}
                        />
                      ))}
                    </div>
                  )}
                </div>

                {/* WhatsApp Alert Gateway Log Console */}
                <WhatsAppLogs lang={lang} />
              </motion.div>
            )}

            {/* ----------------------------------------------------
                ANALYTICS BOARD
                ---------------------------------------------------- */}
            {activeTab === 'analytics' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
                  <h2 className="font-display text-xl font-extrabold text-slate-900 dark:text-white">
                    Power Grid Analytics & AI Insights
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Real-time visual graphs of grid failures, resolution metrics, and workload profiles
                  </p>
                </div>

                <AnalyticsCharts analytics={analytics} />
              </motion.div>
            )}

            {/* ----------------------------------------------------
                COMPLAINT DETAILS VIEW (DEEP DRILL DOWN)
                ---------------------------------------------------- */}
            {activeTab === 'complaint-details' && selectedComplaint && (
              <motion.div
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                {/* Header Back button */}
                <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setActiveTab(user?.role === 'consumer' ? 'history' : user?.role === 'engineer' ? 'engineer-dashboard' : 'admin-dashboard')}
                      className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-500"
                    >
                      <ArrowLeft className="h-4 w-4" />
                    </button>
                    <div>
                      <span className="font-mono text-xs font-bold text-saffron">
                        {selectedComplaint.ticketNumber}
                      </span>
                      <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                        {selectedComplaint.category}
                      </h2>
                    </div>
                  </div>

                  {user?.role === 'admin' && (
                    <button
                      onClick={() => handleDeleteComplaint(selectedComplaint.id)}
                      className="flex items-center gap-1 text-xs font-bold text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 px-3 py-1.5 rounded-lg border border-red-200 dark:border-red-950/40"
                    >
                      <Trash className="h-4 w-4" />
                      <span>Delete Ticket</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Left Column: Complaint Details & Visual Attachments */}
                  <div className="lg:col-span-2 space-y-6">
                    {/* General Metadata card */}
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                          Consumer Details
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                          <div className="text-xs">
                            <p className="text-slate-400">Filed By:</p>
                            <p className="font-bold text-slate-800 dark:text-white">{selectedComplaint.consumerName}</p>
                            <p className="text-slate-400 mt-1">Phone Number:</p>
                            <p className="font-mono font-semibold text-slate-700 dark:text-slate-300">{selectedComplaint.consumerPhone}</p>
                          </div>
                          <div className="text-xs">
                            <p className="text-slate-400">Complaint State/Zone:</p>
                            <p className="font-bold text-slate-800 dark:text-white">{selectedComplaint.location.state} ({selectedComplaint.location.district})</p>
                            <p className="text-slate-400 mt-1">Audit Status:</p>
                            <p className="font-bold text-saffron uppercase tracking-wide">{selectedComplaint.status}</p>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                          Consumer Description
                        </span>
                        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 italic mt-2 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                          "{selectedComplaint.description}"
                        </p>
                      </div>

                      {/* Display Uploaded photo link if present */}
                      {selectedComplaint.imageUrl && (
                        <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono mb-2 block">
                            Photo Evidence Attached
                          </span>
                          <img
                            src={selectedComplaint.imageUrl}
                            alt="Ingested electrical failure detail"
                            className="max-w-md w-full h-auto rounded-xl border object-contain shadow-xs"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      )}
                    </div>

                    {/* AI Diagnostic breakdown */}
                    {selectedComplaint.aiAnalysis && (
                      <div className="rounded-2xl border border-saffron/30 bg-linear-to-tr from-saffron/5 to-white dark:to-slate-900 p-5 space-y-4 shadow-xs">
                        <div className="flex items-center justify-between border-b border-saffron/20 pb-2">
                          <div className="flex items-center gap-1.5">
                            <Sparkles className="h-5 w-5 text-saffron" />
                            <h3 className="text-sm font-bold text-slate-800 dark:text-white">AI Advanced Diagnosis</h3>
                          </div>
                          <span className="text-xs font-mono font-bold text-saffron">
                            Grid Confidence: {selectedComplaint.aiAnalysis.confidence}%
                          </span>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border">
                            <span className="text-slate-400">Severity Index:</span>
                            <p className="font-bold text-slate-800 dark:text-white">{selectedComplaint.aiAnalysis.severity}</p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border">
                            <span className="text-slate-400">Response Priority:</span>
                            <p className="font-bold text-slate-800 dark:text-white">{selectedComplaint.aiAnalysis.priority}</p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border">
                            <span className="text-slate-400">Target Division:</span>
                            <p className="font-bold text-slate-800 dark:text-white">{selectedComplaint.aiAnalysis.department}</p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border">
                            <span className="text-slate-400">Engineer Assigned:</span>
                            <p className="font-bold text-slate-800 dark:text-white truncate">{selectedComplaint.engineerName || 'Awaiting...'}</p>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                            Diagnostic Event Log
                          </span>
                          <p className="text-xs text-slate-600 dark:text-slate-300 italic leading-relaxed">
                            "{selectedComplaint.aiAnalysis.summary}"
                          </p>
                        </div>

                        {/* Dispatch instructions for engineers */}
                        <div className="space-y-1.5 bg-slate-150 dark:bg-slate-950 p-4 rounded-xl border">
                          <span className="text-[10px] font-bold text-govblue dark:text-saffron uppercase tracking-wider font-mono">
                            Technical Repair Checklist (Dispatch Code)
                          </span>
                          <p className="text-xs text-slate-700 dark:text-slate-300 font-medium font-mono leading-relaxed">
                            {selectedComplaint.aiAnalysis.engineerSummary}
                          </p>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider font-mono">
                            Critical Safety Protocol
                          </span>
                          <ul className="text-xs text-slate-600 dark:text-slate-400 pl-4 list-disc space-y-1">
                            {selectedComplaint.aiAnalysis.safety.map((s, idx) => (
                              <li key={idx} className="leading-relaxed">{s}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Right Column: Actions (Status Update & Timeline) */}
                  <div className="space-y-6">
                    {/* Action Form (Only for Admin or Assigned Engineers) */}
                    {(user?.role === 'admin' || (user?.role === 'engineer' && selectedComplaint.engineerId === user.id)) && (
                      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 shadow-xs">
                        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
                          <Shield className="h-5 w-5 text-saffron" />
                          <h3 className="text-sm font-bold text-slate-800 dark:text-white">Field Dispatch Actions</h3>
                        </div>

                        <form onSubmit={handleUpdateComplaintAction} className="space-y-3">
                          {/* If Admin, they can assign engineers */}
                          {user?.role === 'admin' && (
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                                Dispatch Division Lead
                              </label>
                              <select
                                value={assignEngineerId}
                                onChange={(e) => setAssignEngineerId(e.target.value)}
                                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-hidden"
                              >
                                <option value="">Select Lineman / Engineer</option>
                                {engineers.map(e => (
                                  <option key={e.id} value={e.id}>{e.name} ({e.department})</option>
                                ))}
                              </select>
                            </div>
                          )}

                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                              Update Audit Status
                            </label>
                            <select
                              value={statusUpdateVal}
                              onChange={(e) => setStatusUpdateVal(e.target.value)}
                              className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-hidden"
                            >
                              <option value="Submitted">Submitted</option>
                              <option value="Acknowledged">Acknowledged</option>
                              <option value="Assigned">Assigned</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Resolved">Resolved</option>
                              <option value="Closed">Closed</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                              Lineman Action Comments
                            </label>
                            <textarea
                              required
                              value={actionComments}
                              onChange={(e) => setActionComments(e.target.value)}
                              placeholder="e.g. Cleared tree branches, replaced damaged tension clamp. Grid power restored successfully."
                              className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-transparent px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-hidden"
                              rows={3}
                            />
                          </div>

                          <button
                            type="submit"
                            disabled={isUpdatingComplaint}
                            className="w-full rounded-xl bg-saffron text-white font-bold py-2 text-xs active:scale-95 transition-all shadow-sm disabled:opacity-50"
                          >
                            {isUpdatingComplaint ? 'SAVING WORK...' : 'COMMIT DISPATCH LOG'}
                          </button>
                        </form>
                      </div>
                    )}

                    {/* Timeline Tracker */}
                    <ComplaintTimeline logs={selectedComplaint.timeline || []} />
                  </div>
                </div>
              </motion.div>
            )}

            {/* ----------------------------------------------------
                PROFILE & MY ACCOUNT VIEW
                ---------------------------------------------------- */}
            {activeTab === 'profile' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-2xl mx-auto space-y-6"
              >
                <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
                  <h2 className="font-display text-xl font-extrabold text-slate-900 dark:text-white">
                    SECA Grid Identity Board
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Verify account status, contact coordinates, and division assignments
                  </p>
                </div>

                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
                  <div className="flex items-center gap-4">
                    {user?.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="h-16 w-16 rounded-xl object-cover ring-4 ring-saffron/10"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="h-16 w-16 rounded-xl bg-saffron/10 text-saffron flex items-center justify-center font-bold text-xl">
                        {user?.name[0]}
                      </div>
                    )}
                    <div>
                      <h3 className="text-lg font-bold text-slate-800 dark:text-white">{user?.name}</h3>
                      <p className="text-xs text-slate-500 font-medium">Role: <span className="text-saffron font-bold uppercase">{user?.role}</span></p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100 dark:border-slate-800 pt-4 text-xs leading-relaxed">
                    <div>
                      <span className="text-slate-400">Email Address:</span>
                      <p className="font-semibold text-slate-700 dark:text-slate-300">{user?.email}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Phone Contact:</span>
                      <p className="font-mono font-semibold text-slate-700 dark:text-slate-300">{user?.phone}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Sub-Division District:</span>
                      <p className="font-semibold text-slate-700 dark:text-slate-300">{user?.district || 'Corporate Headquarters'}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Grid State:</span>
                      <p className="font-semibold text-slate-700 dark:text-slate-300">{user?.state || 'Delhi, India'}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 py-4 transition-colors duration-200 mt-auto">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500">
            <span>© 2026 SECA India. Ministry of Power utility model.</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 dark:text-slate-500">
            <span>Power Grid Hotline: 1912</span>
            <span>•</span>
            <span className="text-saffron">Smart Diagnostics</span>
          </div>
        </div>
      </footer>

      {/* Floating AI Assistant Chatbot */}
      <AIChatbot lang={lang} token={token} onAutoFillDraft={handleAutoFillDraft} />
    </div>
  );
}
